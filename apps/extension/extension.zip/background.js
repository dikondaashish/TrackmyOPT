"use strict";
(() => {
  // src/config.ts
  var WEBSITE_URL = false ? "https://www.trackmyopt.com" : "https://www.trackmyopt.com";
  var API_ENDPOINTS = {
    ME: `${WEBSITE_URL}/api/me`,
    STATUS: `${WEBSITE_URL}/api/premium/status`,
    AUTH: false ? "https://www.trackmyopt.com/login" : "https://www.trackmyopt.com/login"
  };

  // src/background.ts
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    if (msg.type === "BEGIN_AUTH") {
      beginAuth().then(() => sendResponse({ ok: true })).catch((e) => sendResponse({ ok: false, err: String(e) }));
      return true;
    }
  });
  chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
    if (msg.type === "PING") {
      sendResponse({ ok: true, installed: true, version: chrome.runtime.getManifest().version });
      return true;
    }
    if (msg.type === "TMO_CHECK_EXTENSION") {
      sendResponse({
        ok: true,
        installed: true,
        version: chrome.runtime.getManifest().version,
        type: "TMO_EXTENSION_PRESENT"
      });
      if (sender.tab?.id) {
        chrome.scripting.executeScript({
          target: { tabId: sender.tab.id },
          func: (version) => {
            localStorage.setItem("tmo_extension_connected", "true");
            localStorage.setItem("tmo_extension_version", version);
            localStorage.setItem("tmo_extension_last_sync", (/* @__PURE__ */ new Date()).toISOString());
          },
          args: [chrome.runtime.getManifest().version]
        }).catch(() => {
        });
      }
      return true;
    }
    if (msg.type === "OPEN_TOOL") {
      const toolPage = msg.tool;
      chrome.storage.local.set({ lastPage: toolPage }).then(() => {
        if (chrome.action && chrome.action.openPopup) {
          chrome.action.openPopup().then(() => {
            sendResponse({ ok: true, opened: true });
          }).catch(() => {
            sendResponse({ ok: true, opened: false, message: "Click the TrackMyOPT extension icon to open the tool" });
          });
        } else {
          sendResponse({ ok: true, opened: false, message: "Click the TrackMyOPT extension icon to open the tool" });
        }
      });
      return true;
    }
    sendResponse({ ok: false, error: "Unknown message type" });
    return true;
  });
  async function beginAuth() {
    const tab = await chrome.tabs.create({ url: API_ENDPOINTS.AUTH });
    return new Promise((resolve, reject) => {
      const timeout = setTimeout(() => {
        chrome.tabs.onUpdated.removeListener(listener);
        reject(new Error("Auth timeout"));
      }, 5 * 60 * 1e3);
      const listener = async (tabId, changeInfo, currentTab) => {
        if (tabId !== tab.id)
          return;
        const responseUrl = changeInfo.url || currentTab.url;
        if (!responseUrl)
          return;
        if (responseUrl.includes("/dashboard")) {
          clearTimeout(timeout);
          chrome.tabs.onUpdated.removeListener(listener);
          setTimeout(async () => {
            try {
              const response = await fetch(API_ENDPOINTS.ME, {
                credentials: "include",
                headers: { "Content-Type": "application/json" }
              });
              if (response.ok) {
                await chrome.storage.sync.set({ signedIn: true });
                const token = await chrome.storage.local.get("authToken");
                if (token.authToken) {
                  fetch(`${API_ENDPOINTS.ME.replace("/api/me", "/api/extension/ping")}`, {
                    method: "POST",
                    headers: {
                      "Content-Type": "application/json",
                      "Authorization": `Bearer ${token.authToken}`
                    },
                    body: JSON.stringify({ version: chrome.runtime.getManifest().version })
                  }).catch(() => {
                  });
                }
                if (tab.id) {
                  chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: (version) => {
                      localStorage.setItem("tmo_extension_connected", "true");
                      localStorage.setItem("tmo_extension_version", version);
                      localStorage.setItem("tmo_extension_last_sync", (/* @__PURE__ */ new Date()).toISOString());
                    },
                    args: [chrome.runtime.getManifest().version]
                  }).catch(() => {
                  });
                }
                resolve();
              } else {
                setTimeout(async () => {
                  const retry = await fetch(API_ENDPOINTS.ME, {
                    credentials: "include",
                    headers: { "Content-Type": "application/json" }
                  });
                  if (retry.ok) {
                    await chrome.storage.sync.set({ signedIn: true });
                    resolve();
                  } else {
                    reject(new Error("Could not verify session"));
                  }
                }, 1500);
              }
            } catch (err) {
              reject(err);
            }
          }, 1e3);
          return;
        }
        if (changeInfo.status === "complete" && responseUrl === "about:blank") {
          clearTimeout(timeout);
          chrome.tabs.onUpdated.removeListener(listener);
          reject(new Error("Auth cancelled"));
          return;
        }
      };
      chrome.tabs.onUpdated.addListener(listener);
    });
  }
})();
