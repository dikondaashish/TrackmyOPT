"use strict";
(() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __esm = (fn, res) => function __init() {
    return fn && (res = (0, fn[__getOwnPropNames(fn)[0]])(fn = 0)), res;
  };
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };

  // src/config.ts
  var WEBSITE_URL, API_ENDPOINTS;
  var init_config = __esm({
    "src/config.ts"() {
      "use strict";
      WEBSITE_URL = false ? "https://www.trackmyopt.com" : "https://www.trackmyopt.com";
      API_ENDPOINTS = {
        ME: `${WEBSITE_URL}/api/me`,
        STATUS: `${WEBSITE_URL}/api/premium/status`,
        AUTH: false ? "https://www.trackmyopt.com/login" : "https://www.trackmyopt.com/login"
      };
    }
  });

  // src/navigation.ts
  var navigation_exports = {};
  __export(navigation_exports, {
    getCurrentPage: () => getCurrentPage,
    getLastPage: () => getLastPage,
    getPageData: () => getPageData,
    renderComingSoon: () => renderComingSoon,
    renderPageHeader: () => renderPageHeader,
    savePageData: () => savePageData,
    setCurrentPage: () => setCurrentPage,
    setupPageHandlers: () => setupPageHandlers
  });
  function getCurrentPage() {
    return currentPage;
  }
  function setCurrentPage(page) {
    currentPage = page;
    chrome.storage.local.set({ lastPage: page }).catch(() => {
    });
  }
  async function getLastPage() {
    try {
      const { lastPage } = await chrome.storage.local.get("lastPage");
      return lastPage || null;
    } catch {
      return null;
    }
  }
  async function savePageData(page, data) {
    try {
      await chrome.storage.local.set({ [`${page}_data`]: data });
    } catch {
    }
  }
  async function getPageData(page) {
    try {
      const result = await chrome.storage.local.get(`${page}_data`);
      return result[`${page}_data`] || null;
    } catch {
      return null;
    }
  }
  function renderPageHeader(root, title, subtitle) {
    const headerHTML = `
    <div class="header" role="region" aria-label="${title}">
      <button class="back-btn" id="back-btn" title="Back to home" aria-label="Back to home">
        <span>\u2190</span>
      </button>
      <div class="header-content">
        <h1 class="title">${title}</h1>
        <p class="subtitle">${subtitle}</p>
      </div>
      <div class="header-buttons">
        <button class="theme-btn" id="theme-btn-page" title="Toggle theme" aria-label="Toggle theme">
          <span id="theme-icon-page">\u{1F319}</span>
        </button>
        <button class="logout-btn" id="logout-btn-page" title="Sign out" aria-label="Sign out">
          <span>\u2192</span>
        </button>
      </div>
    </div>
  `;
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = headerHTML;
    root.appendChild(tempDiv.firstElementChild);
  }
  function renderComingSoon(root, message) {
    const noticeHTML = `
    <div class="notice" style="margin-top:12px;">
      <div class="dot">\u{1F6E0}\uFE0F</div>
      <div>
        <div style="font-weight:800; margin-bottom: 4px;">Coming soon</div>
        <div>${message}</div>
      </div>
    </div>
  `;
    const tempDiv = document.createElement("div");
    tempDiv.innerHTML = noticeHTML;
    root.appendChild(tempDiv.firstElementChild);
  }
  async function setupPageHandlers(onBack) {
    const backBtn = document.getElementById("back-btn");
    if (backBtn) {
      backBtn.addEventListener("click", onBack);
    }
    const themeBtn = document.getElementById("theme-btn-page");
    const themeIconPage = document.getElementById("theme-icon-page");
    const { theme } = await chrome.storage.sync.get("theme");
    if (themeIconPage) {
      themeIconPage.textContent = theme === "dark" ? "\u2600\uFE0F" : "\u{1F319}";
    }
    if (themeBtn) {
      themeBtn.addEventListener("click", async () => {
        const body = document.body;
        const isDarkMode = body.classList.contains("dark-mode");
        if (isDarkMode) {
          body.classList.remove("dark-mode");
          await chrome.storage.sync.set({ theme: "light" });
          if (themeIconPage)
            themeIconPage.textContent = "\u{1F319}";
        } else {
          body.classList.add("dark-mode");
          await chrome.storage.sync.set({ theme: "dark" });
          if (themeIconPage)
            themeIconPage.textContent = "\u2600\uFE0F";
        }
      });
    }
    const logoutBtn = document.getElementById("logout-btn-page");
    if (logoutBtn) {
      logoutBtn.addEventListener("click", async () => {
        if (confirm("Are you sure you want to sign out?")) {
          try {
            await fetch("https://www.trackmyopt.com/auth/signout", {
              method: "POST",
              credentials: "include"
            });
          } catch {
          }
          await chrome.storage.sync.clear();
          await chrome.storage.session.clear();
          window.location.reload();
        }
      });
    }
  }
  var currentPage;
  var init_navigation = __esm({
    "src/navigation.ts"() {
      "use strict";
      currentPage = "home";
    }
  });

  // src/pages/opt-countdown.ts
  var opt_countdown_exports = {};
  __export(opt_countdown_exports, {
    renderOptCountdown: () => renderOptCountdown
  });
  function getCardDateFormat(date) {
    const months = [
      "JANUARY",
      "FEBRUARY",
      "MARCH",
      "APRIL",
      "MAY",
      "JUNE",
      "JULY",
      "AUGUST",
      "SEPTEMBER",
      "OCTOBER",
      "NOVEMBER",
      "DECEMBER"
    ];
    return {
      day: String(date.getDate()),
      month: months[date.getMonth()],
      year: String(date.getFullYear())
    };
  }
  function calculateTimeRemaining(targetDate) {
    const now = /* @__PURE__ */ new Date();
    const targetEnd = new Date(targetDate);
    targetEnd.setHours(23, 59, 59, 999);
    const diff = targetEnd.getTime() - now.getTime();
    if (diff <= 0) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0, total: 0 };
    }
    const days = Math.floor(diff / (1e3 * 60 * 60 * 24));
    const hours = Math.floor(diff % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60));
    const minutes = Math.floor(diff % (1e3 * 60 * 60) / (1e3 * 60));
    const seconds = Math.floor(diff % (1e3 * 60) / 1e3);
    return { days, hours, minutes, seconds, total: diff };
  }
  async function checkPremiumStatus() {
    try {
      const { idToken } = await chrome.storage.sync.get("idToken");
      if (idToken) {
        const response2 = await fetch(`${WEBSITE_URL}/api/premium/status`, {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${idToken}`,
            "Content-Type": "application/json"
          }
        });
        if (response2.ok) {
          const result2 = await response2.json();
          return result2.isPremium || false;
        }
      }
      const response = await fetch(`${WEBSITE_URL}/api/premium/status`, {
        method: "GET",
        credentials: "include",
        // Include cookies
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok)
        return false;
      const result = await response.json();
      return result.isPremium || false;
    } catch (error) {
      return false;
    }
  }
  async function loadToolEmail(tool) {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/user/tool-email?tool=${tool}`, {
        method: "GET",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/user/tool-email?tool=${tool}`, {
            method: "GET",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            }
          });
        }
      }
      if (!response.ok)
        return null;
      const result = await response.json();
      return result.email || null;
    } catch (error) {
      return null;
    }
  }
  async function saveToolEmail(tool, email) {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/user/tool-email`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ tool, email })
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/user/tool-email`, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ tool, email })
          });
        }
      }
      return response.ok;
    } catch (error) {
      return false;
    }
  }
  async function renderOptCountdown(root, onBack, results) {
    root.innerHTML = "";
    setCurrentPage("opt-countdown");
    savePageData("opt-countdown", {
      results: {
        earliestStart: results.earliestStart.toISOString(),
        latestEnd: results.latestEnd.toISOString(),
        programEndDate: results.programEndDate.toISOString()
      }
    });
    renderPageHeader(root, "OPT Filing Window", "Your personalized countdown");
    const content = document.createElement("div");
    content.style.cssText = "margin-top: 12px;";
    const startCard = getCardDateFormat(results.earliestStart);
    const now = /* @__PURE__ */ new Date();
    const presentCard = getCardDateFormat(now);
    const endCard = getCardDateFormat(results.latestEnd);
    let countdownInterval = null;
    const isPremium = await checkPremiumStatus();
    const subscribedEmail = await loadToolEmail("opt_apply");
    const hasSubscribed = !!subscribedEmail;
    content.innerHTML = `
    <!-- Date Cards -->
    <div style="display: flex; gap: 8px; margin-bottom: 10px;">
      <!-- Start Date -->
      <div style="flex: 1; background: linear-gradient(135deg, #3b82f6, #2563eb); border-radius: 16px; padding: 12px; color: white; text-align: center; box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);">
        <div style="width: 40px; height: 40px; background: rgba(255,255,255,0.25); border-radius: 10px; margin: 0 auto 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 4px;">
          <div style="font-size: 16px; font-weight: 800; line-height: 1;">${startCard.day}</div>
          <div style="font-size: 7px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">${startCard.month.substring(0, 3)}</div>
          <div style="font-size: 7px; opacity: 0.8;">${startCard.year}</div>
        </div>
        <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">START DATE</div>
      </div>
      
      <!-- Present -->
      <div style="flex: 1; background: linear-gradient(135deg, #10b981, #059669); border-radius: 16px; padding: 12px; color: white; text-align: center; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);">
        <div style="width: 40px; height: 40px; background: rgba(255,255,255,0.25); border-radius: 10px; margin: 0 auto 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 4px;">
          <div style="font-size: 16px; font-weight: 800; line-height: 1;">${presentCard.day}</div>
          <div style="font-size: 7px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">${presentCard.month.substring(0, 3)}</div>
          <div style="font-size: 7px; opacity: 0.8;">${presentCard.year}</div>
        </div>
        <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">PRESENT</div>
      </div>
      
      <!-- End Date -->
      <div style="flex: 1; background: linear-gradient(135deg, #ef4444, #dc2626); border-radius: 16px; padding: 12px; color: white; text-align: center; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);">
        <div style="width: 40px; height: 40px; background: rgba(255,255,255,0.25); border-radius: 10px; margin: 0 auto 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 4px;">
          <div style="font-size: 16px; font-weight: 800; line-height: 1;">${endCard.day}</div>
          <div style="font-size: 7px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">${endCard.month.substring(0, 3)}</div>
          <div style="font-size: 7px; opacity: 0.8;">${endCard.year}</div>
        </div>
        <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">END DATE</div>
      </div>
    </div>
    
    <!-- Countdown Display -->
    <div id="countdown-container" style="border-radius: 20px; padding: 16px; color: white; margin-bottom: 10px; box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3); transition: all 0.5s ease;">
      <div id="days-left-text" style="font-size: 28px; font-weight: 800; text-align: center; margin-bottom: 12px;">-- days left</div>
      
      <!-- Time Boxes -->
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-bottom: 12px;">
        <div style="background: rgba(255,255,255,0.25); border-radius: 10px; padding: 8px 4px; text-align: center;">
          <div id="countdown-days" style="font-size: 20px; font-weight: 800; color: white; transition: transform 0.3s ease;">--</div>
          <div style="font-size: 9px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">DAYS</div>
        </div>
        <div style="background: rgba(255,255,255,0.25); border-radius: 10px; padding: 8px 4px; text-align: center;">
          <div id="countdown-hours" style="font-size: 20px; font-weight: 800; color: white; transition: transform 0.3s ease;">--</div>
          <div style="font-size: 9px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">HOURS</div>
        </div>
        <div style="background: rgba(255,255,255,0.25); border-radius: 10px; padding: 8px 4px; text-align: center;">
          <div id="countdown-minutes" style="font-size: 20px; font-weight: 800; color: white; transition: transform 0.3s ease;">--</div>
          <div style="font-size: 9px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">MINUTES</div>
        </div>
        <div style="background: rgba(255,255,255,0.25); border-radius: 10px; padding: 8px 4px; text-align: center;">
          <div id="countdown-seconds" style="font-size: 20px; font-weight: 800; color: white; transition: transform 0.3s ease;">--</div>
          <div style="font-size: 9px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">SECONDS</div>
        </div>
      </div>
      
      <div id="time-message" style="text-align: center; font-size: 14px; font-weight: 600; opacity: 0.95;">You have plenty of time remaining</div>
    </div>
    
    <!-- Email Reminders Section -->
    <div style="background: linear-gradient(135deg, #3b82f6, #2563eb); border-radius: 20px; padding: 16px; color: white; margin-bottom: 10px; box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3); position: relative; overflow: hidden;">
      ${!isPremium ? `
        <div style="position: absolute; top: 8px; right: 8px; background: #fbbf24; color: #78350f; font-size: 9px; font-weight: 800; padding: 4px 8px; border-radius: 6px; text-transform: uppercase;">
          Premium
        </div>
      ` : ""}
      
      <div style="text-align: center; margin-bottom: 12px;">
        <div style="font-size: 16px; font-weight: 800; margin-bottom: 4px;">\u{1F4E7} Daily Reminders <span style="font-size: 13px; opacity: 0.9;">(9:00 AM ET)</span></div>
        <div style="font-size: 11px; opacity: 0.9; line-height: 1.4;">
          We'll show a Chrome notification every morning. If you enter an email and connect the mailer, we'll also email you.
        </div>
      </div>
      
      <div id="email-reminder-content">
        ${isPremium ? `
          <div style="display: flex; gap: 6px; margin-bottom: ${hasSubscribed ? "10px" : "0px"};">
            <input 
              type="email" 
              id="reminder-email-input"
              placeholder="your@email.com"
              value="${subscribedEmail || ""}"
              style="
                flex: 1;
                padding: 12px;
                border: 0;
                border-radius: 12px;
                background: rgba(255,255,255,0.25);
                color: white;
                font-size: 13px;
                outline: none;
                font-family: inherit;
              "
            />
            <button 
              id="save-email-btn"
              style="
                width: 44px;
                height: 44px;
                border: 0;
                border-radius: 12px;
                background: rgba(255,255,255,0.3);
                color: white;
                font-size: 18px;
                cursor: pointer;
                display: grid;
                place-items: center;
              "
            >\u2192</button>
          </div>
          ${hasSubscribed ? `
            <button 
              id="stop-reminders-btn"
              style="
                width: 100%;
                padding: 12px;
                border: 0;
                border-radius: 12px;
                background: rgba(220, 38, 38, 0.8);
                color: white;
                font-size: 13px;
                font-weight: 700;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
              "
            >
              <span style="font-size: 14px;">\u{1F6D1}</span> Stop Reminders
            </button>
          ` : ""}
        ` : `
          <div style="text-align: center; padding: 16px;">
            <div style="font-size: 24px; margin-bottom: 8px;">\u{1F512}</div>
            <div style="font-size: 13px; font-weight: 700; margin-bottom: 8px;">Unlock Daily Email Reminders</div>
            <div style="font-size: 11px; opacity: 0.9; margin-bottom: 12px;">Get daily email notifications with Pro ($4.99/mo)</div>
            <button 
              id="upgrade-premium-btn"
              style="
                width: 100%;
                padding: 12px;
                border: 0;
                border-radius: 12px;
                background: linear-gradient(135deg, #fbbf24, #f59e0b);
                color: #78350f;
                font-size: 14px;
                font-weight: 800;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(251, 191, 36, 0.4);
              "
            >
              Upgrade to Pro ($4.99/mo)
            </button>
          </div>
        `}
      </div>
    </div>
    
    <!-- Modify Button -->
    <button 
      id="modify-dates-btn"
      style="
        width: 100%;
        padding: 14px;
        border: 0;
        border-radius: 16px;
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
        font-size: 15px;
        font-weight: 800;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
      "
    >
      Modify Approval Date
    </button>
  `;
    root.appendChild(content);
    let previousValues = { days: 0, hours: 0, minutes: 0, seconds: 0 };
    function updateCountdown() {
      const remaining = calculateTimeRemaining(results.latestEnd);
      const daysLeftText = content.querySelector("#days-left-text");
      const daysEl = content.querySelector("#countdown-days");
      const hoursEl = content.querySelector("#countdown-hours");
      const minutesEl = content.querySelector("#countdown-minutes");
      const secondsEl = content.querySelector("#countdown-seconds");
      const messageEl = content.querySelector("#time-message");
      const containerEl = content.querySelector("#countdown-container");
      let gradient = "";
      if (remaining.days > 60) {
        gradient = "linear-gradient(135deg, #34C759, #30D158)";
      } else if (remaining.days > 30) {
        gradient = "linear-gradient(135deg, #007AFF, #5AC8FA)";
      } else if (remaining.days > 14) {
        gradient = "linear-gradient(135deg, #FF9500, #FF9F0A)";
      } else if (remaining.days > 7) {
        gradient = "linear-gradient(135deg, #FF9500, #FF3B30)";
      } else {
        gradient = "linear-gradient(135deg, #FF3B30, #FF453A)";
      }
      if (containerEl) {
        containerEl.style.background = gradient;
      }
      function flipElement(element, newValue) {
        if (!element)
          return;
        element.style.transform = "rotateX(90deg)";
        element.style.opacity = "0";
        setTimeout(() => {
          element.textContent = newValue;
          element.style.transform = "rotateX(0deg)";
          element.style.opacity = "1";
        }, 150);
      }
      const currentDays = String(remaining.days).padStart(2, "0");
      const currentHours = String(remaining.hours).padStart(2, "0");
      const currentMinutes = String(remaining.minutes).padStart(2, "0");
      const currentSeconds = String(remaining.seconds).padStart(2, "0");
      if (daysLeftText)
        daysLeftText.textContent = `${remaining.days} days left`;
      if (daysEl && currentDays !== String(previousValues.days).padStart(2, "0")) {
        flipElement(daysEl, currentDays);
      } else if (daysEl) {
        daysEl.textContent = currentDays;
      }
      if (hoursEl && currentHours !== String(previousValues.hours).padStart(2, "0")) {
        flipElement(hoursEl, currentHours);
      } else if (hoursEl) {
        hoursEl.textContent = currentHours;
      }
      if (minutesEl && currentMinutes !== String(previousValues.minutes).padStart(2, "0")) {
        flipElement(minutesEl, currentMinutes);
      } else if (minutesEl) {
        minutesEl.textContent = currentMinutes;
      }
      if (secondsEl) {
        flipElement(secondsEl, currentSeconds);
      }
      if (messageEl) {
        if (remaining.days > 60) {
          messageEl.textContent = "You have plenty of time remaining";
        } else if (remaining.days > 30) {
          messageEl.textContent = "Time is moving along, stay prepared";
        } else if (remaining.days > 14) {
          messageEl.textContent = "\u26A0\uFE0F Getting closer to the deadline!";
        } else if (remaining.days > 7) {
          messageEl.textContent = "\u26A0\uFE0F Less than two weeks remaining!";
        } else {
          messageEl.textContent = "\u{1F6A8} URGENT: Apply immediately!";
        }
      }
      previousValues = {
        days: remaining.days,
        hours: remaining.hours,
        minutes: remaining.minutes,
        seconds: remaining.seconds
      };
    }
    updateCountdown();
    countdownInterval = window.setInterval(updateCountdown, 1e3);
    const modifyBtn = content.querySelector("#modify-dates-btn");
    if (modifyBtn) {
      modifyBtn.addEventListener("click", () => {
        if (countdownInterval)
          clearInterval(countdownInterval);
        onBack();
      });
    }
    if (isPremium) {
      const saveEmailBtn = content.querySelector("#save-email-btn");
      if (saveEmailBtn) {
        saveEmailBtn.addEventListener("click", async () => {
          const emailInput = content.querySelector("#reminder-email-input");
          const email = emailInput?.value.trim();
          if (!email) {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Email Required",
              message: "Please enter your email address"
            });
            return;
          }
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(email)) {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Invalid Email",
              message: "Please enter a valid email address"
            });
            return;
          }
          const success = await saveToolEmail("opt_apply", email);
          if (success) {
            await chrome.storage.sync.set({ subscribedEmail: email });
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "\u2705 Email Saved!",
              message: `Daily reminders will be sent to ${email} at 9:00 AM ET`
            });
            saveEmailBtn.innerHTML = "\u2705";
            saveEmailBtn.style.background = "rgba(16, 185, 129, 0.8)";
            setTimeout(() => {
              renderOptCountdown(root, onBack, results);
            }, 1e3);
          } else {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Error",
              message: "Failed to save email. Please try again."
            });
          }
        });
      }
      const stopBtn = content.querySelector("#stop-reminders-btn");
      if (stopBtn) {
        stopBtn.addEventListener("click", async () => {
          if (confirm("Are you sure you want to stop daily reminders?")) {
            await saveToolEmail("opt_apply", "");
            await chrome.storage.sync.remove("subscribedEmail");
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Reminders Stopped",
              message: "Daily email reminders have been stopped"
            });
            renderOptCountdown(root, onBack, results);
          }
        });
      }
    } else {
      const upgradeBtn = content.querySelector("#upgrade-premium-btn");
      if (upgradeBtn) {
        upgradeBtn.addEventListener("click", () => {
          chrome.tabs.create({ url: `${WEBSITE_URL}/dashboard?upgrade=true` });
        });
      }
    }
    setupPageHandlers(onBack);
  }
  var init_opt_countdown = __esm({
    "src/pages/opt-countdown.ts"() {
      "use strict";
      init_navigation();
      init_config();
    }
  });

  // src/pages/stem-countdown.ts
  var stem_countdown_exports = {};
  __export(stem_countdown_exports, {
    renderStemCountdown: () => renderStemCountdown
  });
  function getCardDateFormat2(date) {
    const months = [
      "JANUARY",
      "FEBRUARY",
      "MARCH",
      "APRIL",
      "MAY",
      "JUNE",
      "JULY",
      "AUGUST",
      "SEPTEMBER",
      "OCTOBER",
      "NOVEMBER",
      "DECEMBER"
    ];
    return {
      day: String(date.getDate()),
      month: months[date.getMonth()],
      year: String(date.getFullYear())
    };
  }
  function calculateTimeRemaining2(targetDate) {
    const now = /* @__PURE__ */ new Date();
    const diff = targetDate.getTime() - now.getTime();
    if (diff <= 0) {
      return { days: 0, hours: 0, minutes: 0, seconds: 0, total: 0 };
    }
    const days = Math.floor(diff / (1e3 * 60 * 60 * 24));
    const hours = Math.floor(diff % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60));
    const minutes = Math.floor(diff % (1e3 * 60 * 60) / (1e3 * 60));
    const seconds = Math.floor(diff % (1e3 * 60) / 1e3);
    return { days, hours, minutes, seconds, total: diff };
  }
  async function checkPremiumStatus2() {
    try {
      const { idToken } = await chrome.storage.sync.get("idToken");
      if (idToken) {
        const response2 = await fetch(`${WEBSITE_URL}/api/premium/status`, {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${idToken}`,
            "Content-Type": "application/json"
          }
        });
        if (response2.ok) {
          const result2 = await response2.json();
          return result2.isPremium || false;
        }
      }
      const response = await fetch(`${WEBSITE_URL}/api/premium/status`, {
        method: "GET",
        credentials: "include",
        // Include cookies
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok)
        return false;
      const result = await response.json();
      return result.isPremium || false;
    } catch (error) {
      return false;
    }
  }
  async function loadToolEmail2(tool) {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/user/tool-email?tool=${tool}`, {
        method: "GET",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/user/tool-email?tool=${tool}`, {
            method: "GET",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            }
          });
        }
      }
      if (!response.ok)
        return null;
      const result = await response.json();
      return result.email || null;
    } catch (error) {
      return null;
    }
  }
  async function saveToolEmail2(tool, email) {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/user/tool-email`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ tool, email })
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/user/tool-email`, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ tool, email })
          });
        }
      }
      return response.ok;
    } catch (error) {
      return false;
    }
  }
  async function renderStemCountdown(root, onBack, results) {
    root.innerHTML = "";
    setCurrentPage("stem-countdown");
    savePageData("stem-countdown", {
      results: {
        earliestStart: results.earliestStart.toISOString(),
        latestEnd: results.latestEnd.toISOString(),
        currentOptEndDate: results.currentOptEndDate.toISOString()
      }
    });
    renderPageHeader(root, "STEM OPT Filing Window", "Your personalized countdown");
    const content = document.createElement("div");
    content.style.cssText = "margin-top: 12px;";
    const startCard = getCardDateFormat2(results.earliestStart);
    const now = /* @__PURE__ */ new Date();
    const presentCard = getCardDateFormat2(now);
    const endCard = getCardDateFormat2(results.latestEnd);
    let countdownInterval = null;
    const isPremium = await checkPremiumStatus2();
    const subscribedEmail = await loadToolEmail2("stem_apply");
    const hasSubscribed = !!subscribedEmail;
    content.innerHTML = `
    <!-- Date Cards -->
    <div style="display: flex; gap: 8px; margin-bottom: 10px;">
      <!-- Start Date -->
      <div style="flex: 1; background: linear-gradient(135deg, #10b981, #059669); border-radius: 16px; padding: 12px; color: white; text-align: center; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);">
        <div style="width: 40px; height: 40px; background: rgba(255,255,255,0.25); border-radius: 10px; margin: 0 auto 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 4px;">
          <div style="font-size: 16px; font-weight: 800; line-height: 1;">${startCard.day}</div>
          <div style="font-size: 7px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">${startCard.month.substring(0, 3)}</div>
          <div style="font-size: 7px; opacity: 0.8;">${startCard.year}</div>
        </div>
        <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">START DATE</div>
      </div>
      
      <!-- Present -->
      <div style="flex: 1; background: linear-gradient(135deg, #10b981, #059669); border-radius: 16px; padding: 12px; color: white; text-align: center; box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);">
        <div style="width: 40px; height: 40px; background: rgba(255,255,255,0.25); border-radius: 10px; margin: 0 auto 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 4px;">
          <div style="font-size: 16px; font-weight: 800; line-height: 1;">${presentCard.day}</div>
          <div style="font-size: 7px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">${presentCard.month.substring(0, 3)}</div>
          <div style="font-size: 7px; opacity: 0.8;">${presentCard.year}</div>
        </div>
        <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">PRESENT</div>
      </div>
      
      <!-- End Date -->
      <div style="flex: 1; background: linear-gradient(135deg, #ef4444, #dc2626); border-radius: 16px; padding: 12px; color: white; text-align: center; box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);">
        <div style="width: 40px; height: 40px; background: rgba(255,255,255,0.25); border-radius: 10px; margin: 0 auto 8px; display: flex; flex-direction: column; align-items: center; justify-content: center; padding: 4px;">
          <div style="font-size: 16px; font-weight: 800; line-height: 1;">${endCard.day}</div>
          <div style="font-size: 7px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">${endCard.month.substring(0, 3)}</div>
          <div style="font-size: 7px; opacity: 0.8;">${endCard.year}</div>
        </div>
        <div style="font-size: 11px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.5px;">END DATE</div>
      </div>
    </div>
    
    <!-- Countdown Display -->
    <div id="countdown-container" style="border-radius: 20px; padding: 16px; color: white; margin-bottom: 10px; box-shadow: 0 6px 20px rgba(0, 0, 0, 0.3); transition: all 0.5s ease;">
      <div id="days-left-text" style="font-size: 28px; font-weight: 800; text-align: center; margin-bottom: 12px;">-- days left</div>
      
      <!-- Time Boxes -->
      <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-bottom: 12px;">
        <div style="background: rgba(255,255,255,0.25); border-radius: 10px; padding: 8px 4px; text-align: center;">
          <div id="countdown-days" style="font-size: 20px; font-weight: 800; color: #10b981;">--</div>
          <div style="font-size: 9px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">DAYS</div>
        </div>
        <div style="background: rgba(255,255,255,0.25); border-radius: 10px; padding: 8px 4px; text-align: center;">
          <div id="countdown-hours" style="font-size: 20px; font-weight: 800; color: #10b981;">--</div>
          <div style="font-size: 9px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">HOURS</div>
        </div>
        <div style="background: rgba(255,255,255,0.25); border-radius: 10px; padding: 8px 4px; text-align: center;">
          <div id="countdown-minutes" style="font-size: 20px; font-weight: 800; color: #10b981;">--</div>
          <div style="font-size: 9px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">MINUTES</div>
        </div>
        <div style="background: rgba(255,255,255,0.25); border-radius: 10px; padding: 8px 4px; text-align: center;">
          <div id="countdown-seconds" style="font-size: 20px; font-weight: 800; color: #10b981;">--</div>
          <div style="font-size: 9px; font-weight: 600; text-transform: uppercase; opacity: 0.9; margin-top: 2px;">SECONDS</div>
        </div>
      </div>
      
      <div id="time-message" style="text-align: center; font-size: 14px; font-weight: 600; opacity: 0.95;">You have plenty of time remaining</div>
    </div>
    
    <!-- Email Reminders Section -->
    <div style="background: linear-gradient(135deg, #10b981, #059669); border-radius: 20px; padding: 16px; color: white; margin-bottom: 10px; box-shadow: 0 6px 20px rgba(16, 185, 129, 0.3); position: relative; overflow: hidden;">
      ${!isPremium ? `
        <div style="position: absolute; top: 8px; right: 8px; background: #fbbf24; color: #78350f; font-size: 9px; font-weight: 800; padding: 4px 8px; border-radius: 6px; text-transform: uppercase;">
          Premium
        </div>
      ` : ""}
      
      <div style="text-align: center; margin-bottom: 12px;">
        <div style="font-size: 16px; font-weight: 800; margin-bottom: 4px;">\u{1F4E7} Daily Reminders <span style="font-size: 13px; opacity: 0.9;">(9:00 AM ET)</span></div>
        <div style="font-size: 11px; opacity: 0.9; line-height: 1.4;">
          We'll show a Chrome notification every morning. If you enter an email and connect the mailer, we'll also email you.
        </div>
      </div>
      
      <div id="email-reminder-content">
        ${isPremium ? `
          <div style="display: flex; gap: 6px; margin-bottom: ${hasSubscribed ? "10px" : "0px"};">
            <input 
              type="email" 
              id="reminder-email-input"
              placeholder="your@email.com"
              value="${subscribedEmail || ""}"
              style="
                flex: 1;
                padding: 12px;
                border: 0;
                border-radius: 12px;
                background: rgba(255,255,255,0.25);
                color: white;
                font-size: 13px;
                outline: none;
                font-family: inherit;
              "
            />
            <button 
              id="save-email-btn"
              style="
                width: 44px;
                height: 44px;
                border: 0;
                border-radius: 12px;
                background: rgba(255,255,255,0.3);
                color: white;
                font-size: 18px;
                cursor: pointer;
                display: grid;
                place-items: center;
              "
            >\u2192</button>
          </div>
          ${hasSubscribed ? `
            <button 
              id="stop-reminders-btn"
              style="
                width: 100%;
                padding: 12px;
                border: 0;
                border-radius: 12px;
                background: rgba(220, 38, 38, 0.8);
                color: white;
                font-size: 13px;
                font-weight: 700;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 6px;
              "
            >
              <span style="font-size: 14px;">\u{1F6D1}</span> Stop Reminders
            </button>
          ` : ""}
        ` : `
          <div style="text-align: center; padding: 16px;">
            <div style="font-size: 24px; margin-bottom: 8px;">\u{1F512}</div>
            <div style="font-size: 13px; font-weight: 700; margin-bottom: 8px;">Unlock Daily Email Reminders</div>
            <div style="font-size: 11px; opacity: 0.9; margin-bottom: 12px;">Get daily email notifications with Pro ($4.99/mo)</div>
            <button 
              id="upgrade-premium-btn"
              style="
                width: 100%;
                padding: 12px;
                border: 0;
                border-radius: 12px;
                background: linear-gradient(135deg, #fbbf24, #f59e0b);
                color: #78350f;
                font-size: 14px;
                font-weight: 800;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(251, 191, 36, 0.4);
              "
            >
              Upgrade to Pro ($4.99/mo)
            </button>
          </div>
        `}
      </div>
    </div>
    
    <!-- Modify Button -->
    <button 
      id="modify-dates-btn"
      style="
        width: 100%;
        padding: 14px;
        border: 0;
        border-radius: 16px;
        background: linear-gradient(135deg, #10b981, #059669);
        color: white;
        font-size: 15px;
        font-weight: 800;
        cursor: pointer;
        box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
      "
    >
      Modify Approval Date
    </button>
  `;
    root.appendChild(content);
    let previousValues = { days: 0, hours: 0, minutes: 0, seconds: 0 };
    function updateCountdown() {
      const remaining = calculateTimeRemaining2(results.latestEnd);
      const daysLeftText = content.querySelector("#days-left-text");
      const daysEl = content.querySelector("#countdown-days");
      const hoursEl = content.querySelector("#countdown-hours");
      const minutesEl = content.querySelector("#countdown-minutes");
      const secondsEl = content.querySelector("#countdown-seconds");
      const messageEl = content.querySelector("#time-message");
      const containerEl = content.querySelector("#countdown-container");
      let gradient = "";
      if (remaining.days > 60) {
        gradient = "linear-gradient(135deg, #34C759, #30D158)";
      } else if (remaining.days > 30) {
        gradient = "linear-gradient(135deg, #007AFF, #5AC8FA)";
      } else if (remaining.days > 14) {
        gradient = "linear-gradient(135deg, #FF9500, #FF9F0A)";
      } else if (remaining.days > 7) {
        gradient = "linear-gradient(135deg, #FF9500, #FF3B30)";
      } else {
        gradient = "linear-gradient(135deg, #FF3B30, #FF453A)";
      }
      if (containerEl)
        containerEl.style.background = gradient;
      function flipElement(element, newValue) {
        if (!element)
          return;
        element.style.transform = "rotateX(90deg)";
        element.style.opacity = "0";
        setTimeout(() => {
          element.textContent = newValue;
          element.style.transform = "rotateX(0deg)";
          element.style.opacity = "1";
        }, 150);
      }
      const currentDays = String(remaining.days).padStart(2, "0");
      const currentHours = String(remaining.hours).padStart(2, "0");
      const currentMinutes = String(remaining.minutes).padStart(2, "0");
      const currentSeconds = String(remaining.seconds).padStart(2, "0");
      if (daysLeftText)
        daysLeftText.textContent = `${remaining.days} days left`;
      if (daysEl && currentDays !== String(previousValues.days).padStart(2, "0")) {
        flipElement(daysEl, currentDays);
      } else if (daysEl) {
        daysEl.textContent = currentDays;
      }
      if (hoursEl && currentHours !== String(previousValues.hours).padStart(2, "0")) {
        flipElement(hoursEl, currentHours);
      } else if (hoursEl) {
        hoursEl.textContent = currentHours;
      }
      if (minutesEl && currentMinutes !== String(previousValues.minutes).padStart(2, "0")) {
        flipElement(minutesEl, currentMinutes);
      } else if (minutesEl) {
        minutesEl.textContent = currentMinutes;
      }
      if (secondsEl)
        flipElement(secondsEl, currentSeconds);
      if (messageEl) {
        if (remaining.days > 60) {
          messageEl.textContent = "You have plenty of time remaining";
        } else if (remaining.days > 30) {
          messageEl.textContent = "Time is moving along, stay prepared";
        } else if (remaining.days > 14) {
          messageEl.textContent = "\u26A0\uFE0F Getting closer to the deadline!";
        } else if (remaining.days > 7) {
          messageEl.textContent = "\u26A0\uFE0F Less than two weeks remaining!";
        } else {
          messageEl.textContent = "\u{1F6A8} URGENT: Apply immediately!";
        }
      }
      previousValues = { days: remaining.days, hours: remaining.hours, minutes: remaining.minutes, seconds: remaining.seconds };
    }
    updateCountdown();
    countdownInterval = window.setInterval(updateCountdown, 1e3);
    const modifyBtn = content.querySelector("#modify-dates-btn");
    if (modifyBtn) {
      modifyBtn.addEventListener("click", () => {
        if (countdownInterval)
          clearInterval(countdownInterval);
        onBack();
      });
    }
    if (isPremium) {
      const saveEmailBtn = content.querySelector("#save-email-btn");
      if (saveEmailBtn) {
        saveEmailBtn.addEventListener("click", async () => {
          const emailInput = content.querySelector("#reminder-email-input");
          const email = emailInput?.value.trim();
          if (!email) {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Email Required",
              message: "Please enter your email address"
            });
            return;
          }
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(email)) {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Invalid Email",
              message: "Please enter a valid email address"
            });
            return;
          }
          const success = await saveToolEmail2("stem_apply", email);
          if (success) {
            await chrome.storage.sync.set({ subscribedEmail: email });
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "\u2705 Email Saved!",
              message: `Daily reminders will be sent to ${email} at 9:00 AM ET`
            });
            saveEmailBtn.innerHTML = "\u2705";
            saveEmailBtn.style.background = "rgba(16, 185, 129, 0.8)";
            setTimeout(() => {
              renderStemCountdown(root, onBack, results);
            }, 1e3);
          } else {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Error",
              message: "Failed to save email. Please try again."
            });
          }
        });
      }
      const stopBtn = content.querySelector("#stop-reminders-btn");
      if (stopBtn) {
        stopBtn.addEventListener("click", async () => {
          if (confirm("Are you sure you want to stop daily reminders?")) {
            await saveToolEmail2("stem_apply", "");
            await chrome.storage.sync.remove("subscribedEmail");
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Reminders Stopped",
              message: "Daily email reminders have been stopped"
            });
            renderStemCountdown(root, onBack, results);
          }
        });
      }
    } else {
      const upgradeBtn = content.querySelector("#upgrade-premium-btn");
      if (upgradeBtn) {
        upgradeBtn.addEventListener("click", () => {
          chrome.tabs.create({ url: `${WEBSITE_URL}/dashboard?upgrade=true` });
        });
      }
    }
    setupPageHandlers(onBack);
  }
  var init_stem_countdown = __esm({
    "src/pages/stem-countdown.ts"() {
      "use strict";
      init_config();
      init_navigation();
    }
  });

  // src/pages/clock-tracker.ts
  var clock_tracker_exports = {};
  __export(clock_tracker_exports, {
    renderClockTracker: () => renderClockTracker
  });
  function getCardDateFormat3(date) {
    const months = [
      "JANUARY",
      "FEBRUARY",
      "MARCH",
      "APRIL",
      "MAY",
      "JUNE",
      "JULY",
      "AUGUST",
      "SEPTEMBER",
      "OCTOBER",
      "NOVEMBER",
      "DECEMBER"
    ];
    return {
      day: String(date.getDate()),
      month: months[date.getMonth()],
      year: String(date.getFullYear())
    };
  }
  function calculateTimeRemaining3(endDate) {
    const now = /* @__PURE__ */ new Date();
    const total = endDate.getTime() - now.getTime();
    if (total <= 0) {
      return {
        total: 0,
        days: 0,
        hours: 0,
        minutes: 0,
        seconds: 0,
        message: "\u26A0\uFE0F Your OPT period has ended"
      };
    }
    const days = Math.floor(total / (1e3 * 60 * 60 * 24));
    const hours = Math.floor(total % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60));
    const minutes = Math.floor(total % (1e3 * 60 * 60) / (1e3 * 60));
    const seconds = Math.floor(total % (1e3 * 60) / 1e3);
    let message = "";
    if (days <= 7) {
      message = "\u{1F6A8} Urgent! Very little time left";
    } else if (days <= 30) {
      message = "\u26A0\uFE0F Time is running short, act soon";
    } else if (days <= 60) {
      message = "\u23F0 Time is moving along, stay prepared";
    } else {
      message = "\u2705 You have plenty of time remaining";
    }
    return { total, days, hours, minutes, seconds, message };
  }
  async function checkPremiumStatus3() {
    try {
      const { idToken } = await chrome.storage.sync.get("idToken");
      if (idToken) {
        const response2 = await fetch(`${WEBSITE_URL}/api/premium/status`, {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${idToken}`,
            "Content-Type": "application/json"
          }
        });
        if (response2.ok) {
          const result2 = await response2.json();
          return result2.isPremium || false;
        }
      }
      const response = await fetch(`${WEBSITE_URL}/api/premium/status`, {
        method: "GET",
        credentials: "include",
        // Include cookies
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok)
        return false;
      const result = await response.json();
      return result.isPremium || false;
    } catch (error) {
      return false;
    }
  }
  async function loadToolEmail3(tool) {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/user/tool-email?tool=${tool}`, {
        method: "GET",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/user/tool-email?tool=${tool}`, {
            method: "GET",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            }
          });
        }
      }
      if (!response.ok)
        return null;
      const result = await response.json();
      return result.email || null;
    } catch (error) {
      return null;
    }
  }
  async function saveToolEmail3(tool, email) {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/user/tool-email`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ tool, email })
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/user/tool-email`, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ tool, email })
          });
        }
      }
      return response.ok;
    } catch (error) {
      return false;
    }
  }
  function renderClockTracker(root, onBack, startDate) {
    root.innerHTML = "";
    Promise.resolve().then(() => (init_navigation(), navigation_exports)).then(({ setCurrentPage: setCurrentPage2, savePageData: savePageData2 }) => {
      setCurrentPage2("clock-tracker");
      savePageData2("clock-tracker", { startDate: startDate.toISOString() });
    });
    renderPageHeader(root, "OPT Clock Tracker", "Track your OPT timeline with precision");
    const content = document.createElement("div");
    content.style.cssText = "margin-top: 12px;";
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + 90);
    const today = /* @__PURE__ */ new Date();
    const startFormatted = getCardDateFormat3(startDate);
    const todayFormatted = getCardDateFormat3(today);
    const endFormatted = getCardDateFormat3(endDate);
    const dateCardsContainer = document.createElement("div");
    dateCardsContainer.style.cssText = `
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
    margin-bottom: 12px;
  `;
    const startCard = document.createElement("div");
    startCard.style.cssText = `
    padding: 14px 10px;
    border-radius: 16px;
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    color: white;
    text-align: center;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
  `;
    startCard.innerHTML = `
    <div style="margin-bottom: 8px; opacity: 0.9;">
      <div style="width: 36px; height: 36px; margin: 0 auto; background: rgba(255,255,255,0.25); border-radius: 10px; display: grid; place-items: center; font-size: 20px;">
        \u{1F5D3}\uFE0F
      </div>
    </div>
    <div style="font-size: 22px; font-weight: 800; line-height: 1; margin-bottom: 3px;">${startFormatted.day}</div>
    <div style="font-size: 9px; font-weight: 700; letter-spacing: 0.5px; opacity: 0.95; margin-bottom: 2px;">${startFormatted.month}</div>
    <div style="font-size: 11px; font-weight: 600; opacity: 0.9;">${startFormatted.year}</div>
    <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.25); font-size: 10px; font-weight: 700; letter-spacing: 0.5px;">START DATE</div>
  `;
    dateCardsContainer.appendChild(startCard);
    const presentCard = document.createElement("div");
    presentCard.style.cssText = `
    padding: 14px 10px;
    border-radius: 16px;
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
    text-align: center;
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
  `;
    presentCard.innerHTML = `
    <div style="margin-bottom: 8px; opacity: 0.9;">
      <div style="width: 36px; height: 36px; margin: 0 auto; background: rgba(255,255,255,0.25); border-radius: 10px; display: grid; place-items: center; font-size: 20px;">
        \u{1F5D3}\uFE0F
      </div>
    </div>
    <div style="font-size: 22px; font-weight: 800; line-height: 1; margin-bottom: 3px;">${todayFormatted.day}</div>
    <div style="font-size: 9px; font-weight: 700; letter-spacing: 0.5px; opacity: 0.95; margin-bottom: 2px;">${todayFormatted.month}</div>
    <div style="font-size: 11px; font-weight: 600; opacity: 0.9;">${todayFormatted.year}</div>
    <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.25); font-size: 10px; font-weight: 700; letter-spacing: 0.5px;">PRESENT</div>
  `;
    dateCardsContainer.appendChild(presentCard);
    const endCard = document.createElement("div");
    endCard.style.cssText = `
    padding: 14px 10px;
    border-radius: 16px;
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: white;
    text-align: center;
    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
  `;
    endCard.innerHTML = `
    <div style="margin-bottom: 8px; opacity: 0.9;">
      <div style="width: 36px; height: 36px; margin: 0 auto; background: rgba(255,255,255,0.25); border-radius: 10px; display: grid; place-items: center; font-size: 20px;">
        \u{1F5D3}\uFE0F
      </div>
    </div>
    <div style="font-size: 22px; font-weight: 800; line-height: 1; margin-bottom: 3px;">${endFormatted.day}</div>
    <div style="font-size: 9px; font-weight: 700; letter-spacing: 0.5px; opacity: 0.95; margin-bottom: 2px;">${endFormatted.month}</div>
    <div style="font-size: 11px; font-weight: 600; opacity: 0.9;">${endFormatted.year}</div>
    <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.25); font-size: 10px; font-weight: 700; letter-spacing: 0.5px;">END DATE</div>
  `;
    dateCardsContainer.appendChild(endCard);
    content.appendChild(dateCardsContainer);
    const countdownCard = document.createElement("div");
    countdownCard.style.cssText = `
    padding: 20px 16px;
    border-radius: 18px;
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: white;
    margin-bottom: 12px;
    box-shadow: 0 6px 20px rgba(239, 68, 68, 0.3);
  `;
    const timeRemaining = calculateTimeRemaining3(endDate);
    countdownCard.innerHTML = `
    <div id="days-left-text" style="font-size: 28px; font-weight: 800; text-align: center; margin-bottom: 14px; line-height: 1;">${timeRemaining.days} days left</div>
    
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-bottom: 14px;">
      <div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 12px; padding: 10px 6px; text-align: center;">
        <div id="countdown-days" style="font-size: 24px; font-weight: 800; color: #3b82f6; line-height: 1; margin-bottom: 4px;">${String(timeRemaining.days).padStart(2, "0")}</div>
        <div style="font-size: 9px; font-weight: 700; opacity: 0.9; letter-spacing: 0.5px;">DAYS</div>
      </div>
      <div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 12px; padding: 10px 6px; text-align: center;">
        <div id="countdown-hours" style="font-size: 24px; font-weight: 800; color: #3b82f6; line-height: 1; margin-bottom: 4px;">${String(timeRemaining.hours).padStart(2, "0")}</div>
        <div style="font-size: 9px; font-weight: 700; opacity: 0.9; letter-spacing: 0.5px;">HOURS</div>
      </div>
      <div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 12px; padding: 10px 6px; text-align: center;">
        <div id="countdown-minutes" style="font-size: 24px; font-weight: 800; color: #3b82f6; line-height: 1; margin-bottom: 4px;">${String(timeRemaining.minutes).padStart(2, "0")}</div>
        <div style="font-size: 9px; font-weight: 700; opacity: 0.9; letter-spacing: 0.5px;">MINUTES</div>
      </div>
      <div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 12px; padding: 10px 6px; text-align: center;">
        <div id="countdown-seconds" style="font-size: 24px; font-weight: 800; color: #3b82f6; line-height: 1; margin-bottom: 4px;">${String(timeRemaining.seconds).padStart(2, "0")}</div>
        <div style="font-size: 9px; font-weight: 700; opacity: 0.9; letter-spacing: 0.5px;">SECONDS</div>
      </div>
    </div>
    
    <div id="countdown-message" style="text-align: center; font-size: 13px; font-weight: 600; opacity: 0.95;">${timeRemaining.message}</div>
  `;
    content.appendChild(countdownCard);
    const remindersCard = document.createElement("div");
    remindersCard.id = "reminders-card";
    remindersCard.style.cssText = `
    padding: 18px;
    border-radius: 18px;
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    color: white;
    margin-bottom: 12px;
    box-shadow: 0 6px 20px rgba(59, 130, 246, 0.3);
  `;
    remindersCard.innerHTML = `
    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
      <div style="font-size: 22px;">\u{1F4E7}</div>
      <div style="font-weight: 800; font-size: 16px;">Daily Reminders (9:00 AM ET)</div>
    </div>
    <div style="font-size: 12px; opacity: 0.95; margin-bottom: 14px; line-height: 1.5;">
      We'll show a Chrome notification every morning. If you enter an email and connect the mailer, we'll also email you.
    </div>
    <div id="premium-content" style="text-align: center; padding: 20px 10px;">
      <div style="font-size: 13px; margin-bottom: 12px; opacity: 0.95;">\u{1F512} Unlock Daily Email Reminders</div>
      <div style="font-size: 12px; margin-bottom: 14px; opacity: 0.9;">Get daily email notifications with Pro ($4.99/mo)</div>
      <button id="upgrade-btn" style="
        width: 100%;
        padding: 12px;
        border: 0;
        border-radius: 12px;
        background: rgba(255,255,255,0.25);
        backdrop-filter: blur(10px);
        color: white;
        font-weight: 800;
        font-size: 14px;
        cursor: pointer;
        transition: all 0.2s;
        font-family: inherit;
      ">Upgrade to Pro ($4.99/mo)</button>
    </div>
  `;
    content.appendChild(remindersCard);
    const modifyBtn = document.createElement("button");
    modifyBtn.innerHTML = "Modify Start Date";
    modifyBtn.style.cssText = `
    width: 100%;
    padding: 16px;
    border: 0;
    border-radius: 16px;
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
    font-weight: 800;
    font-size: 15px;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 6px 20px rgba(16, 185, 129, 0.3);
    font-family: inherit;
  `;
    content.appendChild(modifyBtn);
    root.appendChild(content);
    let previousValues = { days: 0, hours: 0, minutes: 0, seconds: 0 };
    let countdownInterval = setInterval(() => {
      const remaining = calculateTimeRemaining3(endDate);
      const daysEl = document.getElementById("countdown-days");
      const hoursEl = document.getElementById("countdown-hours");
      const minutesEl = document.getElementById("countdown-minutes");
      const secondsEl = document.getElementById("countdown-seconds");
      const messageEl = document.getElementById("countdown-message");
      const daysLeftEl = document.getElementById("days-left-text");
      const containerEl = document.getElementById("countdown-container");
      let gradient = "";
      if (remaining.days > 60) {
        gradient = "linear-gradient(135deg, #34C759, #30D158)";
      } else if (remaining.days > 30) {
        gradient = "linear-gradient(135deg, #007AFF, #5AC8FA)";
      } else if (remaining.days > 14) {
        gradient = "linear-gradient(135deg, #FF9500, #FF9F0A)";
      } else if (remaining.days > 7) {
        gradient = "linear-gradient(135deg, #FF9500, #FF3B30)";
      } else {
        gradient = "linear-gradient(135deg, #FF3B30, #FF453A)";
      }
      if (containerEl)
        containerEl.style.background = gradient;
      function flipElement(element, newValue) {
        if (!element)
          return;
        element.style.transform = "rotateX(90deg)";
        element.style.opacity = "0";
        setTimeout(() => {
          element.textContent = newValue;
          element.style.transform = "rotateX(0deg)";
          element.style.opacity = "1";
        }, 150);
      }
      const currentDays = String(remaining.days).padStart(2, "0");
      const currentHours = String(remaining.hours).padStart(2, "0");
      const currentMinutes = String(remaining.minutes).padStart(2, "0");
      const currentSeconds = String(remaining.seconds).padStart(2, "0");
      if (daysEl && currentDays !== String(previousValues.days).padStart(2, "0")) {
        flipElement(daysEl, currentDays);
      } else if (daysEl) {
        daysEl.textContent = currentDays;
      }
      if (hoursEl && currentHours !== String(previousValues.hours).padStart(2, "0")) {
        flipElement(hoursEl, currentHours);
      } else if (hoursEl) {
        hoursEl.textContent = currentHours;
      }
      if (minutesEl && currentMinutes !== String(previousValues.minutes).padStart(2, "0")) {
        flipElement(minutesEl, currentMinutes);
      } else if (minutesEl) {
        minutesEl.textContent = currentMinutes;
      }
      if (secondsEl)
        flipElement(secondsEl, currentSeconds);
      if (messageEl)
        messageEl.textContent = remaining.message;
      if (daysLeftEl)
        daysLeftEl.textContent = `${remaining.days} days left`;
      previousValues = { days: remaining.days, hours: remaining.hours, minutes: remaining.minutes, seconds: remaining.seconds };
      if (remaining.total <= 0 && countdownInterval) {
        clearInterval(countdownInterval);
        countdownInterval = null;
      }
    }, 1e3);
    checkPremiumStatus3().then(async (isPremium) => {
      const premiumContent = document.getElementById("premium-content");
      if (!premiumContent)
        return;
      if (isPremium) {
        const savedEmail = await loadToolEmail3("opt_clock");
        if (savedEmail) {
          await chrome.storage.sync.set({ subscribedEmail: savedEmail });
        }
        const hasSubscribed = !!savedEmail;
        premiumContent.innerHTML = `
        <div style="position: relative;">
          <input 
            type="email" 
            id="reminder-email-input" 
            placeholder="your@email.com"
            value="${savedEmail || ""}"
            style="
              width: 100%;
              padding: 14px 50px 14px 16px;
              border: 0;
              border-radius: 12px;
              background: rgba(255,255,255,0.2);
              backdrop-filter: blur(10px);
              color: white;
              font-size: 14px;
              font-weight: 600;
              outline: none;
              margin-bottom: ${hasSubscribed ? "10px" : "0px"};
              font-family: inherit;
            "
          />
          <button 
            id="save-email-btn"
            style="
              position: absolute;
              right: 8px;
              top: 8px;
              padding: 6px 12px;
              border: 0;
              border-radius: 8px;
              background: rgba(255,255,255,0.3);
              color: white;
              cursor: pointer;
              font-size: 18px;
              display: grid;
              place-items: center;
              transition: all 0.2s;
            "
          >\u2192</button>
        </div>
        ${hasSubscribed ? `
          <button id="stop-reminders-btn" style="
            width: 100%;
            padding: 10px;
            border: 0;
            border-radius: 10px;
            background: rgba(255,255,255,0.15);
            backdrop-filter: blur(10px);
            color: white;
            font-weight: 700;
            font-size: 13px;
            cursor: pointer;
            transition: all 0.2s;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 6px;
            font-family: inherit;
          ">
            <span style="font-size: 16px;">\u{1F534}</span>
            <span>Stop Reminders</span>
          </button>
        ` : ""}
      `;
        const saveEmailBtn = document.getElementById("save-email-btn");
        const stopRemindersBtn = document.getElementById("stop-reminders-btn");
        saveEmailBtn?.addEventListener("click", async () => {
          const emailInput = document.getElementById("reminder-email-input");
          const email = emailInput?.value.trim();
          if (!email) {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Email Required",
              message: "Please enter your email address"
            });
            return;
          }
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(email)) {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Invalid Email",
              message: "Please enter a valid email address"
            });
            return;
          }
          const success = await saveToolEmail3("opt_clock", email);
          if (success) {
            await chrome.storage.sync.set({ subscribedEmail: email });
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "\u2705 Email Saved!",
              message: `Daily reminders will be sent to ${email} at 9:00 AM ET`
            });
            if (saveEmailBtn) {
              saveEmailBtn.innerHTML = "\u2705";
              saveEmailBtn.style.background = "rgba(16, 185, 129, 0.8)";
              setTimeout(() => {
                renderClockTracker(root, onBack, startDate);
              }, 1e3);
            }
          } else {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Error",
              message: "Failed to save email. Please try again."
            });
          }
        });
        stopRemindersBtn?.addEventListener("click", async () => {
          if (confirm("Are you sure you want to stop daily reminders?")) {
            await saveToolEmail3("opt_clock", "");
            await chrome.storage.sync.remove("subscribedEmail");
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Reminders Stopped",
              message: "Daily email reminders have been stopped"
            });
            renderClockTracker(root, onBack, startDate);
          }
        });
        saveEmailBtn?.addEventListener("mouseenter", () => {
          if (saveEmailBtn)
            saveEmailBtn.style.background = "rgba(255,255,255,0.4)";
        });
        saveEmailBtn?.addEventListener("mouseleave", () => {
          if (saveEmailBtn)
            saveEmailBtn.style.background = "rgba(255,255,255,0.3)";
        });
        stopRemindersBtn?.addEventListener("mouseenter", () => {
          if (stopRemindersBtn)
            stopRemindersBtn.style.background = "rgba(255,255,255,0.25)";
        });
        stopRemindersBtn?.addEventListener("mouseleave", () => {
          if (stopRemindersBtn)
            stopRemindersBtn.style.background = "rgba(255,255,255,0.15)";
        });
      }
    });
    const upgradeBtn = document.getElementById("upgrade-btn");
    upgradeBtn?.addEventListener("click", () => {
      chrome.tabs.create({ url: `${WEBSITE_URL}/dashboard?upgrade=true` });
    });
    upgradeBtn?.addEventListener("mouseenter", () => {
      if (upgradeBtn)
        upgradeBtn.style.background = "rgba(255,255,255,0.35)";
    });
    upgradeBtn?.addEventListener("mouseleave", () => {
      if (upgradeBtn)
        upgradeBtn.style.background = "rgba(255,255,255,0.25)";
    });
    modifyBtn.addEventListener("click", () => {
      if (countdownInterval) {
        clearInterval(countdownInterval);
        countdownInterval = null;
      }
      onBack();
    });
    modifyBtn.addEventListener("mouseenter", () => {
      modifyBtn.style.transform = "translateY(-2px)";
      modifyBtn.style.boxShadow = "0 8px 24px rgba(16, 185, 129, 0.4)";
    });
    modifyBtn.addEventListener("mouseleave", () => {
      modifyBtn.style.transform = "translateY(0)";
      modifyBtn.style.boxShadow = "0 6px 20px rgba(16, 185, 129, 0.3)";
    });
    setupPageHandlers(onBack);
  }
  var init_clock_tracker = __esm({
    "src/pages/clock-tracker.ts"() {
      "use strict";
      init_config();
      init_navigation();
    }
  });

  // src/pages/stem-clock-tracker.ts
  var stem_clock_tracker_exports = {};
  __export(stem_clock_tracker_exports, {
    renderStemClockTracker: () => renderStemClockTracker
  });
  function getCardDateFormat4(date) {
    const months = [
      "JANUARY",
      "FEBRUARY",
      "MARCH",
      "APRIL",
      "MAY",
      "JUNE",
      "JULY",
      "AUGUST",
      "SEPTEMBER",
      "OCTOBER",
      "NOVEMBER",
      "DECEMBER"
    ];
    return {
      day: String(date.getDate()),
      month: months[date.getMonth()],
      year: String(date.getFullYear())
    };
  }
  function calculateTimeRemaining4(endDate) {
    const now = /* @__PURE__ */ new Date();
    const total = endDate.getTime() - now.getTime();
    if (total <= 0) {
      return {
        total: 0,
        days: 0,
        hours: 0,
        minutes: 0,
        seconds: 0,
        message: "\u26A0\uFE0F Your STEM OPT period has ended"
      };
    }
    const days = Math.floor(total / (1e3 * 60 * 60 * 24));
    const hours = Math.floor(total % (1e3 * 60 * 60 * 24) / (1e3 * 60 * 60));
    const minutes = Math.floor(total % (1e3 * 60 * 60) / (1e3 * 60));
    const seconds = Math.floor(total % (1e3 * 60) / 1e3);
    let message = "";
    if (days <= 7) {
      message = "\u{1F6A8} Urgent! Very little time left";
    } else if (days <= 20) {
      message = "\u26A0\uFE0F Time is running short, act soon";
    } else if (days <= 40) {
      message = "\u23F0 Time is moving along, stay prepared";
    } else {
      message = "\u2705 You have plenty of time remaining";
    }
    return { total, days, hours, minutes, seconds, message };
  }
  async function checkPremiumStatus4() {
    try {
      const { idToken } = await chrome.storage.sync.get("idToken");
      if (idToken) {
        const response2 = await fetch(`${WEBSITE_URL}/api/premium/status`, {
          method: "GET",
          headers: {
            "Authorization": `Bearer ${idToken}`,
            "Content-Type": "application/json"
          }
        });
        if (response2.ok) {
          const result2 = await response2.json();
          return result2.isPremium || false;
        }
      }
      const response = await fetch(`${WEBSITE_URL}/api/premium/status`, {
        method: "GET",
        credentials: "include",
        // Include cookies
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok)
        return false;
      const result = await response.json();
      return result.isPremium || false;
    } catch (error) {
      return false;
    }
  }
  async function loadToolEmail4(tool) {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/user/tool-email?tool=${tool}`, {
        method: "GET",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/user/tool-email?tool=${tool}`, {
            method: "GET",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            }
          });
        }
      }
      if (!response.ok)
        return null;
      const result = await response.json();
      return result.email || null;
    } catch (error) {
      return null;
    }
  }
  async function saveToolEmail4(tool, email) {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/user/tool-email`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify({ tool, email })
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/user/tool-email`, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ tool, email })
          });
        }
      }
      return response.ok;
    } catch (error) {
      return false;
    }
  }
  function renderStemClockTracker(root, onBack, startDate) {
    root.innerHTML = "";
    Promise.resolve().then(() => (init_navigation(), navigation_exports)).then(({ setCurrentPage: setCurrentPage2, savePageData: savePageData2 }) => {
      setCurrentPage2("stem-clock-tracker");
      savePageData2("stem-clock-tracker", { startDate: startDate.toISOString() });
    });
    renderPageHeader(root, "STEM OPT Clock Tracker", "Track your STEM OPT timeline with precision");
    const content = document.createElement("div");
    content.style.cssText = "margin-top: 12px;";
    const endDate = new Date(startDate);
    endDate.setDate(endDate.getDate() + 60);
    const today = /* @__PURE__ */ new Date();
    const startFormatted = getCardDateFormat4(startDate);
    const todayFormatted = getCardDateFormat4(today);
    const endFormatted = getCardDateFormat4(endDate);
    const dateCardsContainer = document.createElement("div");
    dateCardsContainer.style.cssText = `
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 8px;
    margin-bottom: 12px;
  `;
    const startCard = document.createElement("div");
    startCard.style.cssText = `
    padding: 14px 10px;
    border-radius: 16px;
    background: linear-gradient(135deg, #f97316, #ea580c);
    color: white;
    text-align: center;
    box-shadow: 0 4px 12px rgba(249, 115, 22, 0.3);
  `;
    startCard.innerHTML = `
    <div style="margin-bottom: 8px; opacity: 0.9;">
      <div style="width: 36px; height: 36px; margin: 0 auto; background: rgba(255,255,255,0.25); border-radius: 10px; display: grid; place-items: center; font-size: 20px;">
        \u{1F5D3}\uFE0F
      </div>
    </div>
    <div style="font-size: 22px; font-weight: 800; line-height: 1; margin-bottom: 3px;">${startFormatted.day}</div>
    <div style="font-size: 9px; font-weight: 700; letter-spacing: 0.5px; opacity: 0.95; margin-bottom: 2px;">${startFormatted.month}</div>
    <div style="font-size: 11px; font-weight: 600; opacity: 0.9;">${startFormatted.year}</div>
    <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.25); font-size: 10px; font-weight: 700; letter-spacing: 0.5px;">START DATE</div>
  `;
    dateCardsContainer.appendChild(startCard);
    const presentCard = document.createElement("div");
    presentCard.style.cssText = `
    padding: 14px 10px;
    border-radius: 16px;
    background: linear-gradient(135deg, #f97316, #ea580c);
    color: white;
    text-align: center;
    box-shadow: 0 4px 12px rgba(249, 115, 22, 0.3);
  `;
    presentCard.innerHTML = `
    <div style="margin-bottom: 8px; opacity: 0.9;">
      <div style="width: 36px; height: 36px; margin: 0 auto; background: rgba(255,255,255,0.25); border-radius: 10px; display: grid; place-items: center; font-size: 20px;">
        \u{1F5D3}\uFE0F
      </div>
    </div>
    <div style="font-size: 22px; font-weight: 800; line-height: 1; margin-bottom: 3px;">${todayFormatted.day}</div>
    <div style="font-size: 9px; font-weight: 700; letter-spacing: 0.5px; opacity: 0.95; margin-bottom: 2px;">${todayFormatted.month}</div>
    <div style="font-size: 11px; font-weight: 600; opacity: 0.9;">${todayFormatted.year}</div>
    <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.25); font-size: 10px; font-weight: 700; letter-spacing: 0.5px;">PRESENT</div>
  `;
    dateCardsContainer.appendChild(presentCard);
    const endCard = document.createElement("div");
    endCard.style.cssText = `
    padding: 14px 10px;
    border-radius: 16px;
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: white;
    text-align: center;
    box-shadow: 0 4px 12px rgba(239, 68, 68, 0.3);
  `;
    endCard.innerHTML = `
    <div style="margin-bottom: 8px; opacity: 0.9;">
      <div style="width: 36px; height: 36px; margin: 0 auto; background: rgba(255,255,255,0.25); border-radius: 10px; display: grid; place-items: center; font-size: 20px;">
        \u{1F5D3}\uFE0F
      </div>
    </div>
    <div style="font-size: 22px; font-weight: 800; line-height: 1; margin-bottom: 3px;">${endFormatted.day}</div>
    <div style="font-size: 9px; font-weight: 700; letter-spacing: 0.5px; opacity: 0.95; margin-bottom: 2px;">${endFormatted.month}</div>
    <div style="font-size: 11px; font-weight: 600; opacity: 0.9;">${endFormatted.year}</div>
    <div style="margin-top: 8px; padding-top: 8px; border-top: 1px solid rgba(255,255,255,0.25); font-size: 10px; font-weight: 700; letter-spacing: 0.5px;">END DATE</div>
  `;
    dateCardsContainer.appendChild(endCard);
    content.appendChild(dateCardsContainer);
    const countdownCard = document.createElement("div");
    countdownCard.style.cssText = `
    padding: 20px 16px;
    border-radius: 18px;
    background: linear-gradient(135deg, #ef4444, #dc2626);
    color: white;
    margin-bottom: 12px;
    box-shadow: 0 6px 20px rgba(239, 68, 68, 0.3);
  `;
    const timeRemaining = calculateTimeRemaining4(endDate);
    countdownCard.innerHTML = `
    <div id="days-left-text" style="font-size: 28px; font-weight: 800; text-align: center; margin-bottom: 14px; line-height: 1;">${timeRemaining.days} days left</div>
    
    <div style="display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px; margin-bottom: 14px;">
      <div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 12px; padding: 10px 6px; text-align: center;">
        <div id="countdown-days" style="font-size: 24px; font-weight: 800; color: #f97316; line-height: 1; margin-bottom: 4px;">${String(timeRemaining.days).padStart(2, "0")}</div>
        <div style="font-size: 9px; font-weight: 700; opacity: 0.9; letter-spacing: 0.5px;">DAYS</div>
      </div>
      <div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 12px; padding: 10px 6px; text-align: center;">
        <div id="countdown-hours" style="font-size: 24px; font-weight: 800; color: #f97316; line-height: 1; margin-bottom: 4px;">${String(timeRemaining.hours).padStart(2, "0")}</div>
        <div style="font-size: 9px; font-weight: 700; opacity: 0.9; letter-spacing: 0.5px;">HOURS</div>
      </div>
      <div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 12px; padding: 10px 6px; text-align: center;">
        <div id="countdown-minutes" style="font-size: 24px; font-weight: 800; color: #f97316; line-height: 1; margin-bottom: 4px;">${String(timeRemaining.minutes).padStart(2, "0")}</div>
        <div style="font-size: 9px; font-weight: 700; opacity: 0.9; letter-spacing: 0.5px;">MINUTES</div>
      </div>
      <div style="background: rgba(255,255,255,0.2); backdrop-filter: blur(10px); border-radius: 12px; padding: 10px 6px; text-align: center;">
        <div id="countdown-seconds" style="font-size: 24px; font-weight: 800; color: #f97316; line-height: 1; margin-bottom: 4px;">${String(timeRemaining.seconds).padStart(2, "0")}</div>
        <div style="font-size: 9px; font-weight: 700; opacity: 0.9; letter-spacing: 0.5px;">SECONDS</div>
      </div>
    </div>
    
    <div id="countdown-message" style="text-align: center; font-size: 13px; font-weight: 600; opacity: 0.95;">${timeRemaining.message}</div>
  `;
    content.appendChild(countdownCard);
    const remindersCard = document.createElement("div");
    remindersCard.id = "reminders-card";
    remindersCard.style.cssText = `
    padding: 18px;
    border-radius: 18px;
    background: linear-gradient(135deg, #f97316, #ea580c);
    color: white;
    margin-bottom: 12px;
    box-shadow: 0 6px 20px rgba(249, 115, 22, 0.3);
  `;
    remindersCard.innerHTML = `
    <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 12px;">
      <div style="font-size: 22px;">\u{1F4E7}</div>
      <div style="font-weight: 800; font-size: 16px;">Daily Reminders (9:00 AM ET)</div>
    </div>
    <div style="font-size: 12px; opacity: 0.95; margin-bottom: 14px; line-height: 1.5;">
      We'll show a Chrome notification every morning. If you enter an email and connect the mailer, we'll also email you.
    </div>
    <div id="premium-content" style="text-align: center; padding: 20px 10px;">
      <div style="font-size: 13px; margin-bottom: 12px; opacity: 0.95;">\u{1F512} Unlock Daily Email Reminders</div>
      <div style="font-size: 12px; margin-bottom: 14px; opacity: 0.9;">Get daily email notifications with Pro ($4.99/mo)</div>
      <button id="upgrade-btn" style="
        width: 100%;
        padding: 12px;
        border: 0;
        border-radius: 12px;
        background: rgba(255,255,255,0.25);
        backdrop-filter: blur(10px);
        color: white;
        font-weight: 800;
        font-size: 14px;
        cursor: pointer;
        transition: all 0.2s;
        font-family: inherit;
      ">Upgrade to Pro ($4.99/mo)</button>
    </div>
  `;
    content.appendChild(remindersCard);
    const modifyBtn = document.createElement("button");
    modifyBtn.innerHTML = "Modify Start Date";
    modifyBtn.style.cssText = `
    width: 100%;
    padding: 16px;
    border: 0;
    border-radius: 16px;
    background: linear-gradient(135deg, #22c55e, #16a34a);
    color: white;
    font-weight: 800;
    font-size: 15px;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 6px 20px rgba(34, 197, 94, 0.3);
    font-family: inherit;
  `;
    content.appendChild(modifyBtn);
    root.appendChild(content);
    let previousValues = { days: 0, hours: 0, minutes: 0, seconds: 0 };
    let countdownInterval = setInterval(() => {
      const remaining = calculateTimeRemaining4(endDate);
      const daysEl = document.getElementById("countdown-days");
      const hoursEl = document.getElementById("countdown-hours");
      const minutesEl = document.getElementById("countdown-minutes");
      const secondsEl = document.getElementById("countdown-seconds");
      const messageEl = document.getElementById("countdown-message");
      const daysLeftEl = document.getElementById("days-left-text");
      const containerEl = document.getElementById("countdown-container");
      let gradient = "";
      if (remaining.days > 40) {
        gradient = "linear-gradient(135deg, #34C759, #30D158)";
      } else if (remaining.days > 20) {
        gradient = "linear-gradient(135deg, #007AFF, #5AC8FA)";
      } else if (remaining.days > 10) {
        gradient = "linear-gradient(135deg, #FF9500, #FF9F0A)";
      } else if (remaining.days > 5) {
        gradient = "linear-gradient(135deg, #FF9500, #FF3B30)";
      } else {
        gradient = "linear-gradient(135deg, #FF3B30, #FF453A)";
      }
      if (containerEl)
        containerEl.style.background = gradient;
      function flipElement(element, newValue) {
        if (!element)
          return;
        element.style.transform = "rotateX(90deg)";
        element.style.opacity = "0";
        setTimeout(() => {
          element.textContent = newValue;
          element.style.transform = "rotateX(0deg)";
          element.style.opacity = "1";
        }, 150);
      }
      const currentDays = String(remaining.days).padStart(2, "0");
      const currentHours = String(remaining.hours).padStart(2, "0");
      const currentMinutes = String(remaining.minutes).padStart(2, "0");
      const currentSeconds = String(remaining.seconds).padStart(2, "0");
      if (daysEl && currentDays !== String(previousValues.days).padStart(2, "0")) {
        flipElement(daysEl, currentDays);
      } else if (daysEl) {
        daysEl.textContent = currentDays;
      }
      if (hoursEl && currentHours !== String(previousValues.hours).padStart(2, "0")) {
        flipElement(hoursEl, currentHours);
      } else if (hoursEl) {
        hoursEl.textContent = currentHours;
      }
      if (minutesEl && currentMinutes !== String(previousValues.minutes).padStart(2, "0")) {
        flipElement(minutesEl, currentMinutes);
      } else if (minutesEl) {
        minutesEl.textContent = currentMinutes;
      }
      if (secondsEl)
        flipElement(secondsEl, currentSeconds);
      if (messageEl)
        messageEl.textContent = remaining.message;
      if (daysLeftEl)
        daysLeftEl.textContent = `${remaining.days} days left`;
      previousValues = { days: remaining.days, hours: remaining.hours, minutes: remaining.minutes, seconds: remaining.seconds };
      if (remaining.total <= 0 && countdownInterval) {
        clearInterval(countdownInterval);
        countdownInterval = null;
      }
    }, 1e3);
    checkPremiumStatus4().then(async (isPremium) => {
      const premiumContent = document.getElementById("premium-content");
      if (!premiumContent)
        return;
      if (isPremium) {
        const savedEmail = await loadToolEmail4("stem_clock");
        premiumContent.innerHTML = `
        <div style="position: relative;">
          <input 
            type="email" 
            id="reminder-email-input" 
            placeholder="your@email.com"
            value="${savedEmail || ""}"
            style="
              width: 100%;
              padding: 14px 50px 14px 16px;
              border: 0;
              border-radius: 12px;
              background: rgba(255,255,255,0.2);
              backdrop-filter: blur(10px);
              color: white;
              font-size: 14px;
              font-weight: 600;
              outline: none;
              margin-bottom: 10px;
              font-family: inherit;
            "
          />
          <button 
            id="save-email-btn"
            style="
              position: absolute;
              right: 8px;
              top: 8px;
              padding: 6px 12px;
              border: 0;
              border-radius: 8px;
              background: rgba(255,255,255,0.3);
              color: white;
              cursor: pointer;
              font-size: 18px;
              display: grid;
              place-items: center;
              transition: all 0.2s;
            "
          >\u2192</button>
        </div>
        <button id="stop-reminders-btn" style="
          width: 100%;
          padding: 10px;
          border: 0;
          border-radius: 10px;
          background: rgba(255,255,255,0.15);
          backdrop-filter: blur(10px);
          color: white;
          font-weight: 700;
          font-size: 13px;
          cursor: pointer;
          transition: all 0.2s;
          display: flex;
          align-items: center;
          justify-content: center;
          gap: 6px;
          font-family: inherit;
        ">
          <span style="font-size: 16px;">\u{1F534}</span>
          <span>Stop Reminders</span>
        </button>
      `;
        const saveEmailBtn = document.getElementById("save-email-btn");
        const stopRemindersBtn = document.getElementById("stop-reminders-btn");
        saveEmailBtn?.addEventListener("click", async () => {
          const emailInput = document.getElementById("reminder-email-input");
          const email = emailInput?.value.trim();
          if (!email) {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Email Required",
              message: "Please enter your email address"
            });
            return;
          }
          const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
          if (!emailRegex.test(email)) {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Invalid Email",
              message: "Please enter a valid email address"
            });
            return;
          }
          const success = await saveToolEmail4("stem_clock", email);
          if (success) {
            await chrome.storage.sync.set({ subscribedEmail: email });
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "\u2705 Email Saved!",
              message: `Daily reminders will be sent to ${email} at 9:00 AM ET`
            });
            if (saveEmailBtn) {
              saveEmailBtn.innerHTML = "\u2705";
              saveEmailBtn.style.background = "rgba(16, 185, 129, 0.8)";
              setTimeout(() => {
                renderStemClockTracker(root, onBack, startDate);
              }, 1e3);
            }
          } else {
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Error",
              message: "Failed to save email. Please try again."
            });
          }
        });
        stopRemindersBtn?.addEventListener("click", async () => {
          if (confirm("Are you sure you want to stop daily reminders?")) {
            await saveToolEmail4("stem_clock", "");
            await chrome.storage.sync.remove("subscribedEmail");
            chrome.notifications.create({
              type: "basic",
              iconUrl: "icons/icon128.png",
              title: "Reminders Stopped",
              message: "Daily email reminders have been stopped"
            });
            renderStemClockTracker(root, onBack, startDate);
          }
        });
        saveEmailBtn?.addEventListener("mouseenter", () => {
          if (saveEmailBtn)
            saveEmailBtn.style.background = "rgba(255,255,255,0.4)";
        });
        saveEmailBtn?.addEventListener("mouseleave", () => {
          if (saveEmailBtn)
            saveEmailBtn.style.background = "rgba(255,255,255,0.3)";
        });
        stopRemindersBtn?.addEventListener("mouseenter", () => {
          if (stopRemindersBtn)
            stopRemindersBtn.style.background = "rgba(255,255,255,0.25)";
        });
        stopRemindersBtn?.addEventListener("mouseleave", () => {
          if (stopRemindersBtn)
            stopRemindersBtn.style.background = "rgba(255,255,255,0.15)";
        });
      }
    });
    const upgradeBtn = document.getElementById("upgrade-btn");
    upgradeBtn?.addEventListener("click", () => {
      chrome.tabs.create({ url: `${WEBSITE_URL}/dashboard?upgrade=true` });
    });
    upgradeBtn?.addEventListener("mouseenter", () => {
      if (upgradeBtn)
        upgradeBtn.style.background = "rgba(255,255,255,0.35)";
    });
    upgradeBtn?.addEventListener("mouseleave", () => {
      if (upgradeBtn)
        upgradeBtn.style.background = "rgba(255,255,255,0.25)";
    });
    modifyBtn.addEventListener("click", () => {
      if (countdownInterval) {
        clearInterval(countdownInterval);
        countdownInterval = null;
      }
      onBack();
    });
    modifyBtn.addEventListener("mouseenter", () => {
      modifyBtn.style.transform = "translateY(-2px)";
      modifyBtn.style.boxShadow = "0 8px 24px rgba(34, 197, 94, 0.4)";
    });
    modifyBtn.addEventListener("mouseleave", () => {
      modifyBtn.style.transform = "translateY(0)";
      modifyBtn.style.boxShadow = "0 6px 20px rgba(34, 197, 94, 0.3)";
    });
    setupPageHandlers(onBack);
  }
  var init_stem_clock_tracker = __esm({
    "src/pages/stem-clock-tracker.ts"() {
      "use strict";
      init_config();
      init_navigation();
    }
  });

  // src/home.ts
  init_config();
  async function renderHome(root, onNavigate) {
    let planBadge = "";
    try {
      const res = await fetch(API_ENDPOINTS.STATUS, { credentials: "include" });
      if (res.ok) {
        const data = await res.json();
        if (data.isPremium && data.planName) {
          const plan = data.planName.toUpperCase();
          const badgeClass = plan === "DEDICATED" ? "badge-dedicated" : "badge-pro";
          planBadge = `<span class="plan-badge ${badgeClass}">${plan}</span>`;
        }
      }
    } catch (err) {
      console.error("Failed to fetch premium status for extension", err);
    }
    root.innerHTML = `
    <style>
      .plan-badge {
        font-size: 8px;
        font-weight: 800;
        padding: 1.5px 4px;
        border-radius: 3px;
        margin-left: 6px;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        vertical-align: middle;
        display: inline-block;
        line-height: 1;
      }
      .badge-pro {
        background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
        color: white;
        box-shadow: 0 2px 4px rgba(37, 99, 235, 0.3);
      }
      .badge-dedicated {
        background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%);
        color: white;
        box-shadow: 0 2px 4px rgba(217, 119, 6, 0.3);
      }
      .header-title-container {
        display: flex;
        align-items: center;
        margin-bottom: 2px;
      }
    </style>
    <div class="header" role="region" aria-label="TrackMyOPT header">
      <div class="logo-icon">
        <img src="icons/logo.gif" alt="TrackMyOPT Logo" style="width: 100%; height: 100%; object-fit: cover; display: block;">
      </div>
      <div class="header-buttons">
        <button class="theme-btn" id="theme-btn" title="Toggle theme" aria-label="Toggle theme">
          <span id="theme-icon">\u{1F319}</span>
        </button>
        <button class="logout-btn" id="logout-btn" title="Sign out" aria-label="Sign out">
          <span>\u2192</span>
        </button>
      </div>
      <div class="header-title-container">
        <h1 class="title" style="margin-bottom: 0;">TrackMyOPT</h1>
        ${planBadge}
      </div>
      <p class="subtitle">Your complete toolkit for managing OPT requirements</p>
    </div>

    <div class="banner" aria-live="polite">
      Select a tool below to get started with your OPT journey
    </div>

    <div class="grid" role="list">
      <div class="tile blue" role="button" tabindex="0" aria-label="OPT Apply Start Dates - Calculate when you can start applying for OPT" data-page="opt-apply">
        <div class="icon">\u{1F5D3}\uFE0F</div>
        <h3 class="t">OPT Apply Dates</h3>
        <p class="s">Calculate when you can apply for OPT</p>
      </div>

      <div class="tile purple" role="button" tabindex="0" aria-label="OPT Clock Tracker - Track your OPT unemployment days in real-time" data-page="clock">
        <div class="icon">\u23F0</div>
        <h3 class="t">OPT Clock Tracker</h3>
        <p class="s">Track your unemployment days</p>
      </div>

      <div class="tile green" role="button" tabindex="0" aria-label="STEM OPT Apply Start Dates - Calculate STEM OPT extension application dates" data-page="stem-apply">
        <div class="icon">\u{1F393}</div>
        <h3 class="t">STEM Apply Dates</h3>
        <p class="s">Calculate STEM OPT dates</p>
      </div>

      <div class="tile orange" role="button" tabindex="0" aria-label="STEM OPT Clock Tracker - Track your STEM OPT unemployment days" data-page="stem-clock">
        <div class="icon">\u23F2\uFE0F</div>
        <h3 class="t">STEM Clock Tracker</h3>
        <p class="s">Track STEM unemployment</p>
      </div>
    </div>

    <div class="notice">
      <div class="dot">\u{1F6E1}\uFE0F</div>
      <div>
        <div style="font-weight:800; margin-bottom: 4px;">Stay Compliant</div>
        <div>All tools are designed to help you track and manage your OPT requirements. Always consult with your DSO for official guidance.</div>
      </div>
    </div>

    <div class="footer">
      <a class="link" target="_blank" rel="noreferrer" href="https://www.trackmyopt.com/privacy">Privacy</a> \xB7
      <a class="link" target="_blank" rel="noreferrer" href="https://www.trackmyopt.com/terms">Terms</a>
    </div>
  `;
    const tiles = root.querySelectorAll(".tile");
    tiles.forEach((tile) => {
      const page = tile.dataset.page;
      const href = tile.dataset.link;
      const navigate = () => {
        if (page) {
          onNavigate(page);
        } else if (href) {
          chrome.tabs.create({ url: href });
        }
      };
      tile.addEventListener("click", navigate);
      tile.addEventListener("keydown", (e) => {
        if (e.key === "Enter" || e.key === " ") {
          e.preventDefault();
          navigate();
        }
      });
    });
    const themeBtn = root.querySelector(".theme-btn");
    const themeIcon = root.querySelector("#theme-icon");
    const { theme } = await chrome.storage.sync.get("theme");
    if (themeIcon) {
      themeIcon.textContent = theme === "dark" ? "\u2600\uFE0F" : "\u{1F319}";
    }
    if (themeBtn) {
      themeBtn.addEventListener("click", async () => {
        const body = document.body;
        const isDarkMode = body.classList.contains("dark-mode");
        if (isDarkMode) {
          body.classList.remove("dark-mode");
          await chrome.storage.sync.set({ theme: "light" });
          if (themeIcon)
            themeIcon.textContent = "\u{1F319}";
        } else {
          body.classList.add("dark-mode");
          await chrome.storage.sync.set({ theme: "dark" });
          if (themeIcon)
            themeIcon.textContent = "\u2600\uFE0F";
        }
      });
    }
    const logoutBtn = document.getElementById("logout-btn");
    if (logoutBtn) {
      logoutBtn.addEventListener("click", async () => {
        if (confirm("Are you sure you want to sign out?")) {
          try {
            await fetch("https://www.trackmyopt.com/auth/signout", {
              method: "POST",
              credentials: "include"
            });
          } catch {
          }
          await chrome.storage.sync.clear();
          await chrome.storage.session.clear();
          window.location.reload();
        }
      });
    }
  }

  // src/locked.ts
  async function renderLocked(root) {
    root.innerHTML = `
    <div class="header">
      <div class="header-buttons">
        <button class="theme-btn" id="theme-btn-locked" title="Toggle theme" aria-label="Toggle theme">
          <span id="theme-icon-locked">\u{1F319}</span>
        </button>
      </div>
      <h1 class="title" style="font-size: 24px; margin-bottom: 8px;">TrackMyOPT</h1>
      <p class="subtitle" style="font-size: 13px; opacity: 0.7;">Your OPT Timeline Companion</p>
    </div>
    
    <div style="margin-top: 20px; padding: 0 4px;">
      <!-- Features List -->
      <div style="display: flex; flex-direction: column; gap: 12px; margin-bottom: 20px;">
        <div style="display: flex; align-items: start; gap: 12px;">
          <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #3b82f6 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 18px;">\u{1F5D3}\uFE0F</div>
          <div style="flex: 1;">
            <div style="font-weight: 600; font-size: 14px; margin-bottom: 2px;">Track Your Timeline</div>
            <div style="font-size: 12px; opacity: 0.7; line-height: 1.4;">Real-time countdown to critical OPT deadlines</div>
          </div>
        </div>
        
        <div style="display: flex; align-items: start; gap: 12px;">
          <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #3b82f6 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 18px;">\u{1F9EE}</div>
          <div style="flex: 1;">
            <div style="font-weight: 600; font-size: 14px; margin-bottom: 2px;">Filing Windows</div>
            <div style="font-size: 12px; opacity: 0.7; line-height: 1.4;">Know exactly when to apply for OPT & STEM</div>
          </div>
        </div>
        
        <div style="display: flex; align-items: start; gap: 12px;">
          <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #3b82f6 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 18px;">\u{1F4CA}</div>
          <div style="flex: 1;">
            <div style="font-weight: 600; font-size: 14px; margin-bottom: 2px;">Unemployment Tracking</div>
            <div style="font-size: 12px; opacity: 0.7; line-height: 1.4;">Monitor and manage your 90/150 day limits</div>
          </div>
        </div>
        
        <div style="display: flex; align-items: start; gap: 12px;">
          <div style="width: 40px; height: 40px; background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #3b82f6 100%); border-radius: 12px; display: flex; align-items: center; justify-content: center; flex-shrink: 0; font-size: 18px;">\u{1F514}</div>
          <div style="flex: 1;">
            <div style="font-weight: 600; font-size: 14px; margin-bottom: 2px;">Smart Reminders</div>
            <div style="font-size: 12px; opacity: 0.7; line-height: 1.4;">Never miss important dates and deadlines</div>
          </div>
        </div>
      </div>
      
      <!-- CTA Button -->
      <div style="margin-top: 12px;">
        <button id="signin-btn" style="width: 100%; background: linear-gradient(135deg, #1e3a8a 0%, #1e40af 50%, #3b82f6 100%); color: white; border: none; padding: 14px; border-radius: 12px; font-weight: 600; font-size: 14px; cursor: pointer; transition: transform 0.2s, box-shadow 0.2s; box-shadow: 0 4px 12px rgba(30, 64, 175, 0.4);">
          Sign In or Create Account
        </button>
      </div>
    </div>

    <div class="footer" style="margin-top: 12px; font-size: 11px;">
      <a class="link" target="_blank" rel="noreferrer" href="https://www.trackmyopt.com/privacy">Privacy</a> \xB7
      <a class="link" target="_blank" rel="noreferrer" href="https://www.trackmyopt.com/terms">Terms</a>
    </div>
  `;
    const signinBtn = document.getElementById("signin-btn");
    if (signinBtn) {
      signinBtn.addEventListener("click", () => {
        chrome.tabs.create({ url: "https://www.trackmyopt.com/login" });
      });
      signinBtn.addEventListener("mouseenter", () => {
        signinBtn.style.transform = "translateY(-2px)";
        signinBtn.style.boxShadow = "0 6px 16px rgba(30, 64, 175, 0.5)";
      });
      signinBtn.addEventListener("mouseleave", () => {
        signinBtn.style.transform = "translateY(0)";
        signinBtn.style.boxShadow = "0 4px 12px rgba(30, 64, 175, 0.4)";
      });
    }
    const themeBtnLocked = document.getElementById("theme-btn-locked");
    const themeIconLocked = document.getElementById("theme-icon-locked");
    const { theme } = await chrome.storage.sync.get("theme");
    if (themeIconLocked) {
      themeIconLocked.textContent = theme === "dark" ? "\u2600\uFE0F" : "\u{1F319}";
    }
    if (themeBtnLocked) {
      themeBtnLocked.addEventListener("click", async () => {
        const body = document.body;
        const isDarkMode = body.classList.contains("dark-mode");
        if (isDarkMode) {
          body.classList.remove("dark-mode");
          await chrome.storage.sync.set({ theme: "light" });
          if (themeIconLocked)
            themeIconLocked.textContent = "\u{1F319}";
        } else {
          body.classList.add("dark-mode");
          await chrome.storage.sync.set({ theme: "dark" });
          if (themeIconLocked)
            themeIconLocked.textContent = "\u2600\uFE0F";
        }
      });
    }
  }

  // src/pages/opt-apply.ts
  init_config();
  init_navigation();
  function formatDate(date) {
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  }
  function validateDateInput(input) {
    let cleaned = input.replace(/[^\d/]/g, "");
    cleaned = cleaned.substring(0, 10);
    const parts = cleaned.split("/");
    if (parts.length >= 1 && parts[0].length > 0) {
      let month = parseInt(parts[0]);
      if (month > 12) {
        parts[0] = "12";
      } else if (parts[0].length === 2 && month === 0) {
        parts[0] = "01";
      }
      parts[0] = parts[0].substring(0, 2);
    }
    if (parts.length >= 2 && parts[1].length > 0) {
      let month = parseInt(parts[0]) || 1;
      let day = parseInt(parts[1]);
      const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      const maxDay = daysInMonth[month - 1] || 31;
      if (day > maxDay) {
        parts[1] = String(maxDay).padStart(2, "0");
      } else if (parts[1].length === 2 && day === 0) {
        parts[1] = "01";
      }
      parts[1] = parts[1].substring(0, 2);
    }
    if (parts.length >= 3) {
      parts[2] = parts[2].substring(0, 4);
    }
    return parts.join("/");
  }
  function addDateInputValidation(inputElement) {
    inputElement.addEventListener("input", (e) => {
      const target = e.target;
      const cursorPosition = target.selectionStart || 0;
      const oldValue = target.value;
      const newValue = validateDateInput(oldValue);
      if (newValue !== oldValue) {
        target.value = newValue;
        target.setSelectionRange(cursorPosition, cursorPosition);
      }
    });
    inputElement.addEventListener("keypress", (e) => {
      const char = e.key;
      if (!/[\d/]/.test(char) && !["Backspace", "Delete", "ArrowLeft", "ArrowRight", "Tab"].includes(e.key)) {
        e.preventDefault();
      }
    });
  }
  function getMonthName(month) {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ];
    return months[month];
  }
  function getDaysInMonth(year, month) {
    return new Date(year, month + 1, 0).getDate();
  }
  function getFirstDayOfMonth(year, month) {
    return new Date(year, month, 1).getDay();
  }
  function createDatePicker(inputId, onSelect) {
    const today = /* @__PURE__ */ new Date();
    let currentYear = today.getFullYear();
    let currentMonth = today.getMonth();
    const picker = document.createElement("div");
    picker.style.cssText = `
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    margin-top: 8px;
    background: white;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
    padding: 14px;
    z-index: 1000;
    animation: slideDown 0.2s ease;
  `;
    const style = document.createElement("style");
    style.textContent = `
    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
    document.head.appendChild(style);
    function renderCalendar() {
      picker.innerHTML = "";
      const header = document.createElement("div");
      header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      padding-bottom: 10px;
      border-bottom: 2px solid #e5e7eb;
    `;
      const prevBtn = document.createElement("button");
      prevBtn.innerHTML = "\u2191";
      prevBtn.style.cssText = `
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 8px;
      background: #f3f4f6;
      color: #374151;
      cursor: pointer;
      font-size: 18px;
      font-weight: 700;
      transition: all 0.2s;
    `;
      prevBtn.addEventListener("mouseenter", () => {
        prevBtn.style.background = "#e5e7eb";
      });
      prevBtn.addEventListener("mouseleave", () => {
        prevBtn.style.background = "#f3f4f6";
      });
      prevBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        currentMonth--;
        if (currentMonth < 0) {
          currentMonth = 11;
          currentYear--;
        }
        renderCalendar();
      });
      const monthYear = document.createElement("div");
      monthYear.style.cssText = `
      font-weight: 700;
      font-size: 14px;
      color: #111827;
    `;
      monthYear.innerHTML = `${getMonthName(currentMonth)} ${currentYear} <span style="font-size: 12px; color: #6b7280;">\u25BC</span>`;
      const nextBtn = document.createElement("button");
      nextBtn.innerHTML = "\u2193";
      nextBtn.style.cssText = `
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 8px;
      background: #f3f4f6;
      color: #374151;
      cursor: pointer;
      font-size: 18px;
      font-weight: 700;
      transition: all 0.2s;
    `;
      nextBtn.addEventListener("mouseenter", () => {
        nextBtn.style.background = "#e5e7eb";
      });
      nextBtn.addEventListener("mouseleave", () => {
        nextBtn.style.background = "#f3f4f6";
      });
      nextBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        currentMonth++;
        if (currentMonth > 11) {
          currentMonth = 0;
          currentYear++;
        }
        renderCalendar();
      });
      header.appendChild(prevBtn);
      header.appendChild(monthYear);
      header.appendChild(nextBtn);
      picker.appendChild(header);
      const dayHeaders = document.createElement("div");
      dayHeaders.style.cssText = `
      display: grid;
      grid-template-columns: repeat(7, 1fr);
      gap: 4px;
      margin-bottom: 8px;
    `;
      ["S", "M", "T", "W", "T", "F", "S"].forEach((day) => {
        const dayHeader = document.createElement("div");
        dayHeader.textContent = day;
        dayHeader.style.cssText = `
        text-align: center;
        font-size: 11px;
        font-weight: 700;
        color: #6b7280;
        padding: 4px 0;
      `;
        dayHeaders.appendChild(dayHeader);
      });
      picker.appendChild(dayHeaders);
      const daysGrid = document.createElement("div");
      daysGrid.style.cssText = `
      display: grid;
      grid-template-columns: repeat(7, 1fr);
      gap: 4px;
    `;
      const firstDay = getFirstDayOfMonth(currentYear, currentMonth);
      const daysInMonth = getDaysInMonth(currentYear, currentMonth);
      const prevMonthDays = currentMonth === 0 ? getDaysInMonth(currentYear - 1, 11) : getDaysInMonth(currentYear, currentMonth - 1);
      for (let i = firstDay - 1; i >= 0; i--) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(prevMonthDays - i);
        dayBtn.style.cssText = `
        width: 100%;
        aspect-ratio: 1;
        border: 0;
        border-radius: 8px;
        background: transparent;
        color: #d1d5db;
        font-size: 12px;
        cursor: pointer;
      `;
        daysGrid.appendChild(dayBtn);
      }
      for (let day = 1; day <= daysInMonth; day++) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(day);
        const isToday = day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();
        dayBtn.style.cssText = `
        width: 100%;
        aspect-ratio: 1;
        border: 0;
        border-radius: 8px;
        background: ${isToday ? "#3b82f6" : "transparent"};
        color: ${isToday ? "white" : "#111827"};
        font-size: 12px;
        font-weight: ${isToday ? "700" : "500"};
        cursor: pointer;
        transition: all 0.15s;
      `;
        dayBtn.addEventListener("mouseenter", () => {
          if (!isToday) {
            dayBtn.style.background = "#f3f4f6";
          }
        });
        dayBtn.addEventListener("mouseleave", () => {
          if (!isToday) {
            dayBtn.style.background = "transparent";
          }
        });
        const selectedDate = new Date(currentYear, currentMonth, day);
        dayBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          onSelect(selectedDate);
          picker.remove();
        });
        daysGrid.appendChild(dayBtn);
      }
      const remainingCells = 42 - (firstDay + daysInMonth);
      for (let i = 1; i <= remainingCells; i++) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(i);
        dayBtn.style.cssText = `
        width: 100%;
        aspect-ratio: 1;
        border: 0;
        border-radius: 8px;
        background: transparent;
        color: #d1d5db;
        font-size: 12px;
        cursor: pointer;
      `;
        daysGrid.appendChild(dayBtn);
      }
      picker.appendChild(daysGrid);
      const footer = document.createElement("div");
      footer.style.cssText = `
      display: flex;
      justify-content: space-between;
      margin-top: 12px;
      padding-top: 10px;
      border-top: 1px solid #e5e7eb;
    `;
      const clearBtn = document.createElement("button");
      clearBtn.textContent = "Clear";
      clearBtn.style.cssText = `
      padding: 6px 12px;
      border: 0;
      border-radius: 6px;
      background: transparent;
      color: #3b82f6;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    `;
      clearBtn.addEventListener("mouseenter", () => {
        clearBtn.style.background = "#eff6ff";
      });
      clearBtn.addEventListener("mouseleave", () => {
        clearBtn.style.background = "transparent";
      });
      clearBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const input = document.getElementById(inputId);
        if (input)
          input.value = "";
        picker.remove();
      });
      const todayBtn = document.createElement("button");
      todayBtn.textContent = "Today";
      todayBtn.style.cssText = `
      padding: 6px 12px;
      border: 0;
      border-radius: 6px;
      background: transparent;
      color: #3b82f6;
      font-size: 12px;
      font-weight: 600;
      cursor: pointer;
      transition: all 0.2s;
    `;
      todayBtn.addEventListener("mouseenter", () => {
        todayBtn.style.background = "#eff6ff";
      });
      todayBtn.addEventListener("mouseleave", () => {
        todayBtn.style.background = "transparent";
      });
      todayBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        onSelect(today);
        picker.remove();
      });
      footer.appendChild(clearBtn);
      footer.appendChild(todayBtn);
      picker.appendChild(footer);
    }
    renderCalendar();
    return picker;
  }
  function parseDate(dateStr) {
    const parts = dateStr.split("/");
    if (parts.length !== 3)
      return null;
    const month = parseInt(parts[0], 10) - 1;
    const day = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);
    if (isNaN(month) || isNaN(day) || isNaN(year))
      return null;
    const date = new Date(year, month, day);
    if (date.getFullYear() !== year || date.getMonth() !== month || date.getDate() !== day) {
      return null;
    }
    return date;
  }
  function addDays(date, days) {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }
  function calculateFilingWindow(programEndDate, dsoRecommendationDate) {
    const earliestStart = addDays(programEndDate, -90);
    const latestEnd = addDays(programEndDate, 60);
    return {
      earliestStart,
      latestEnd,
      programEndDate
    };
  }
  async function loadSavedData() {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
        method: "GET",
        credentials: "include",
        // Send cookies from website
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
            method: "GET",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            }
          });
        }
      }
      if (!response.ok)
        return null;
      const result = await response.json();
      return result.ok ? result.data : null;
    } catch (error) {
      return null;
    }
  }
  async function saveDatesToAPI(programEndDate, dsoRecommendationDate) {
    try {
      const existingData = await loadSavedData();
      let lastModifiedField = null;
      if (dsoRecommendationDate && dsoRecommendationDate !== existingData?.dso_recommendation_date) {
        lastModifiedField = "dso_recommendation_date";
      }
      if (programEndDate && programEndDate !== existingData?.program_end_date) {
        lastModifiedField = "program_end_date";
      }
      const payload = {
        program_end_date: programEndDate,
        dso_recommendation_date: dsoRecommendationDate,
        // Preserve existing values for other fields
        opt_start_date: existingData?.opt_start_date || null,
        opt_ead_end_date: existingData?.opt_ead_end_date || null,
        stem_start_date: existingData?.stem_start_date || null,
        _lastModifiedField: lastModifiedField
        // Tell API which field was updated
      };
      let response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
        method: "POST",
        credentials: "include",
        // Send cookies from website
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
            method: "POST",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify(payload)
          });
        }
      }
      const result = await response.json();
      if (result.ok) {
        return true;
      } else {
        return false;
      }
    } catch (error) {
      return false;
    }
  }
  function renderOptApply(root, onBack) {
    root.innerHTML = "";
    renderPageHeader(root, "OPT Apply Dates", "Calculate your OPT filing window");
    const content = document.createElement("div");
    content.style.cssText = "margin-top: 12px;";
    const infoCard = document.createElement("div");
    infoCard.style.cssText = `
    padding: 14px;
    border-radius: 14px;
    background: linear-gradient(135deg, #3b82f6, #6366f1);
    color: white;
    margin-bottom: 12px;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.25);
  `;
    infoCard.innerHTML = `
    <div style="display: flex; gap: 10px; align-items: start;">
      <div style="flex-shrink: 0; width: 28px; height: 28px; border-radius: 50%; background: rgba(255,255,255,0.2); display: grid; place-items: center; font-size: 16px;">
        \u2139\uFE0F
      </div>
      <div>
        <div style="font-weight: 700; font-size: 13px; margin-bottom: 6px;">Post-Completion OPT Filing Rules</div>
        <div style="font-size: 12px; line-height: 1.5; opacity: 0.95;">
          You can apply 90 days before your program ends, up to 60 days after. USCIS must receive your I-765 within 30 days of your DSO's recommendation.
        </div>
      </div>
    </div>
  `;
    content.appendChild(infoCard);
    const programCard = document.createElement("div");
    programCard.style.cssText = `
    padding: 14px;
    border-radius: 14px;
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    color: white;
    margin-bottom: 12px;
    box-shadow: 0 4px 12px rgba(37, 99, 235, 0.25);
    position: relative;
  `;
    programCard.innerHTML = `
    <div style="display: flex; gap: 10px; align-items: start; margin-bottom: 10px;">
      <div style="flex-shrink: 0; width: 36px; height: 36px; border-radius: 10px; background: rgba(255,255,255,0.2); display: grid; place-items: center; font-size: 18px;">
        \u{1F5D3}\uFE0F
      </div>
      <div style="flex: 1;">
        <div style="font-weight: 700; font-size: 14px; margin-bottom: 2px;">Program End Date</div>
        <div style="font-size: 11px; opacity: 0.9;">From your I-20</div>
      </div>
    </div>
    <div style="position: relative;">
      <input 
        type="text" 
        id="program-end-date" 
        placeholder="mm/dd/yyyy"
        style="
          width: 100%;
          padding: 10px 40px 10px 12px;
          border: 0;
          border-radius: 10px;
          background: rgba(255,255,255,0.15);
          backdrop-filter: blur(10px);
          color: white;
          font-size: 14px;
          outline: none;
          font-family: inherit;
        "
      />
      <button 
        id="program-date-picker-btn"
        style="
          position: absolute;
          right: 8px;
          top: 50%;
          transform: translateY(-50%);
          width: 32px;
          height: 32px;
          border: 0;
          border-radius: 8px;
          background: rgba(255,255,255,0.2);
          color: white;
          cursor: pointer;
          font-size: 16px;
          display: grid;
          place-items: center;
          transition: all 0.2s;
        "
      >\u{1F5D3}\uFE0F</button>
    </div>
  `;
    content.appendChild(programCard);
    const dsoCard = document.createElement("div");
    dsoCard.style.cssText = `
    padding: 14px;
    border-radius: 14px;
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
    margin-bottom: 12px;
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);
    position: relative;
  `;
    dsoCard.innerHTML = `
    <div style="display: flex; gap: 10px; align-items: start; margin-bottom: 10px;">
      <div style="flex-shrink: 0; width: 36px; height: 36px; border-radius: 10px; background: rgba(255,255,255,0.2); display: grid; place-items: center; font-size: 18px;">
        \u{1F5D3}\uFE0F
      </div>
      <div style="flex: 1;">
        <div style="font-weight: 700; font-size: 14px; margin-bottom: 2px;">DSO Recommendation Date</div>
        <div style="font-size: 11px; opacity: 0.9;">Optional - When DSO signed your I-20</div>
      </div>
    </div>
    <div style="position: relative;">
      <input 
        type="text" 
        id="dso-recommendation-date" 
        placeholder="mm/dd/yyyy"
        style="
          width: 100%;
          padding: 10px 40px 10px 12px;
          border: 0;
          border-radius: 10px;
          background: rgba(255,255,255,0.15);
          backdrop-filter: blur(10px);
          color: white;
          font-size: 14px;
          outline: none;
          font-family: inherit;
        "
      />
      <button 
        id="dso-date-picker-btn"
        style="
          position: absolute;
          right: 8px;
          top: 50%;
          transform: translateY(-50%);
          width: 32px;
          height: 32px;
          border: 0;
          border-radius: 8px;
          background: rgba(255,255,255,0.2);
          color: white;
          cursor: pointer;
          font-size: 16px;
          display: grid;
          place-items: center;
          transition: all 0.2s;
        "
      >\u{1F5D3}\uFE0F</button>
    </div>
  `;
    content.appendChild(dsoCard);
    const calculateBtn = document.createElement("button");
    calculateBtn.textContent = "Calculate Filing Window";
    calculateBtn.style.cssText = `
    width: 100%;
    padding: 14px;
    border: 0;
    border-radius: 12px;
    background: linear-gradient(135deg, #374151, #1f2937);
    color: white;
    font-weight: 700;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    font-family: inherit;
  `;
    content.appendChild(calculateBtn);
    const resultsContainer = document.createElement("div");
    resultsContainer.id = "results-container";
    resultsContainer.style.cssText = "margin-top: 12px;";
    content.appendChild(resultsContainer);
    root.appendChild(content);
    const programDatePickerBtn = document.getElementById("program-date-picker-btn");
    const dsoDatePickerBtn = document.getElementById("dso-date-picker-btn");
    let activePicker = null;
    document.addEventListener("click", (e) => {
      if (activePicker && !activePicker.contains(e.target)) {
        const pickerButtons = [programDatePickerBtn, dsoDatePickerBtn];
        const isPickerButton = pickerButtons.some((btn) => btn?.contains(e.target));
        if (!isPickerButton) {
          activePicker.remove();
          activePicker = null;
        }
      }
    });
    programDatePickerBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (activePicker) {
        activePicker.remove();
        activePicker = null;
      }
      const picker = createDatePicker("program-end-date", (date) => {
        const input = document.getElementById("program-end-date");
        if (input) {
          input.value = formatDate(date);
        }
        activePicker = null;
      });
      const container = programDatePickerBtn.closest('div[style*="position: relative"]');
      if (container) {
        container.appendChild(picker);
        activePicker = picker;
      }
    });
    dsoDatePickerBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (activePicker) {
        activePicker.remove();
        activePicker = null;
      }
      const picker = createDatePicker("dso-recommendation-date", (date) => {
        const input = document.getElementById("dso-recommendation-date");
        if (input) {
          input.value = formatDate(date);
        }
        activePicker = null;
      });
      const container = dsoDatePickerBtn.closest('div[style*="position: relative"]');
      if (container) {
        container.appendChild(picker);
        activePicker = picker;
      }
    });
    [programDatePickerBtn, dsoDatePickerBtn].forEach((btn) => {
      if (btn) {
        btn.addEventListener("mouseenter", () => {
          btn.style.background = "rgba(255,255,255,0.3)";
        });
        btn.addEventListener("mouseleave", () => {
          btn.style.background = "rgba(255,255,255,0.2)";
        });
      }
    });
    const autoSaveDates = () => {
      const programEndInput2 = document.getElementById("program-end-date");
      const dsoRecommendationInput2 = document.getElementById("dso-recommendation-date");
      const programEnd = programEndInput2.value.trim();
      const dsoRec = dsoRecommendationInput2.value.trim();
      if (programEnd && parseDate(programEnd)) {
        saveDatesToAPI(programEnd, dsoRec || null);
      }
    };
    calculateBtn.addEventListener("click", async () => {
      const programEndInput2 = document.getElementById("program-end-date");
      const dsoRecommendationInput2 = document.getElementById("dso-recommendation-date");
      const programEndDate = parseDate(programEndInput2.value);
      if (!programEndDate) {
        resultsContainer.innerHTML = `
        <div style="padding: 12px; border-radius: 12px; background: #fef2f2; color: #991b1b; font-size: 13px; border: 1px solid #fecaca;">
          \u274C Please enter a valid Program End Date (mm/dd/yyyy)
        </div>
      `;
        return;
      }
      const dsoRecommendationDate = dsoRecommendationInput2.value.trim() ? parseDate(dsoRecommendationInput2.value) : null;
      if (dsoRecommendationInput2.value.trim() && !dsoRecommendationDate) {
        resultsContainer.innerHTML = `
        <div style="padding: 12px; border-radius: 12px; background: #fef2f2; color: #991b1b; font-size: 13px; border: 1px solid #fecaca;">
          \u274C Please enter a valid DSO Recommendation Date (mm/dd/yyyy)
        </div>
      `;
        return;
      }
      await saveDatesToAPI(
        programEndInput2.value.trim(),
        dsoRecommendationInput2.value.trim() || null
      );
      const results = calculateFilingWindow(programEndDate, dsoRecommendationDate);
      const { renderOptCountdown: renderOptCountdown2 } = await Promise.resolve().then(() => (init_opt_countdown(), opt_countdown_exports));
      renderOptCountdown2(root, onBack, results);
    });
    const inputs = [
      document.getElementById("program-end-date"),
      document.getElementById("dso-recommendation-date")
    ];
    inputs.forEach((input) => {
      if (input) {
        input.addEventListener("focus", (e) => {
          e.target.style.background = "rgba(255,255,255,0.25)";
        });
        input.addEventListener("blur", (e) => {
          e.target.style.background = "rgba(255,255,255,0.15)";
        });
      }
    });
    calculateBtn.addEventListener("mouseenter", () => {
      calculateBtn.style.transform = "translateY(-1px)";
      calculateBtn.style.boxShadow = "0 6px 16px rgba(0, 0, 0, 0.2)";
    });
    calculateBtn.addEventListener("mouseleave", () => {
      calculateBtn.style.transform = "translateY(0)";
      calculateBtn.style.boxShadow = "0 4px 12px rgba(0, 0, 0, 0.15)";
    });
    const programEndInput = document.getElementById("program-end-date");
    const dsoRecommendationInput = document.getElementById("dso-recommendation-date");
    if (programEndInput) {
      addDateInputValidation(programEndInput);
      programEndInput.addEventListener("blur", () => {
        setTimeout(autoSaveDates, 300);
      });
    }
    if (dsoRecommendationInput) {
      addDateInputValidation(dsoRecommendationInput);
      dsoRecommendationInput.addEventListener("blur", () => {
        setTimeout(autoSaveDates, 300);
      });
    }
    loadSavedData().then((savedData) => {
      if (savedData && programEndInput) {
        if (savedData.program_end_date) {
          programEndInput.value = savedData.program_end_date;
        }
        if (savedData.dso_recommendation_date && dsoRecommendationInput) {
          dsoRecommendationInput.value = savedData.dso_recommendation_date;
        }
      }
    });
    setupPageHandlers(onBack);
  }

  // src/pages/stem-apply.ts
  init_config();
  init_navigation();
  function formatDate2(date) {
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  }
  function validateDateInput2(input) {
    let cleaned = input.replace(/[^\d/]/g, "");
    cleaned = cleaned.substring(0, 10);
    const parts = cleaned.split("/");
    if (parts.length >= 1 && parts[0].length > 0) {
      let month = parseInt(parts[0]);
      if (month > 12) {
        parts[0] = "12";
      } else if (parts[0].length === 2 && month === 0) {
        parts[0] = "01";
      }
      parts[0] = parts[0].substring(0, 2);
    }
    if (parts.length >= 2 && parts[1].length > 0) {
      let month = parseInt(parts[0]) || 1;
      let day = parseInt(parts[1]);
      const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      const maxDay = daysInMonth[month - 1] || 31;
      if (day > maxDay) {
        parts[1] = String(maxDay).padStart(2, "0");
      } else if (parts[1].length === 2 && day === 0) {
        parts[1] = "01";
      }
      parts[1] = parts[1].substring(0, 2);
    }
    if (parts.length >= 3) {
      parts[2] = parts[2].substring(0, 4);
    }
    return parts.join("/");
  }
  function addDateInputValidation2(inputElement) {
    inputElement.addEventListener("input", (e) => {
      const target = e.target;
      const cursorPosition = target.selectionStart || 0;
      const oldValue = target.value;
      const newValue = validateDateInput2(oldValue);
      if (newValue !== oldValue) {
        target.value = newValue;
        target.setSelectionRange(cursorPosition, cursorPosition);
      }
    });
    inputElement.addEventListener("keypress", (e) => {
      const char = e.key;
      if (!/[\d/]/.test(char) && !["Backspace", "Delete", "ArrowLeft", "ArrowRight", "Tab"].includes(e.key)) {
        e.preventDefault();
      }
    });
  }
  function getMonthName2(month) {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ];
    return months[month];
  }
  function getDaysInMonth2(year, month) {
    return new Date(year, month + 1, 0).getDate();
  }
  function getFirstDayOfMonth2(year, month) {
    return new Date(year, month, 1).getDay();
  }
  function createDatePicker2(inputId, onSelect) {
    const today = /* @__PURE__ */ new Date();
    let currentYear = today.getFullYear();
    let currentMonth = today.getMonth();
    const picker = document.createElement("div");
    picker.style.cssText = `
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    margin-top: 8px;
    background: white;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
    padding: 14px;
    z-index: 1000;
    animation: slideDown 0.2s ease;
  `;
    const style = document.createElement("style");
    style.textContent = `
    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
    document.head.appendChild(style);
    function renderCalendar() {
      picker.innerHTML = "";
      const header = document.createElement("div");
      header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      padding-bottom: 10px;
      border-bottom: 2px solid #e5e7eb;
    `;
      const prevBtn = document.createElement("button");
      prevBtn.innerHTML = "\u2191";
      prevBtn.style.cssText = `
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 8px;
      background: #f3f4f6;
      color: #374151;
      cursor: pointer;
      font-size: 18px;
      font-weight: 700;
      transition: all 0.2s;
    `;
      prevBtn.addEventListener("mouseenter", () => {
        prevBtn.style.background = "#e5e7eb";
      });
      prevBtn.addEventListener("mouseleave", () => {
        prevBtn.style.background = "#f3f4f6";
      });
      prevBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        currentMonth--;
        if (currentMonth < 0) {
          currentMonth = 11;
          currentYear--;
        }
        renderCalendar();
      });
      const monthYear = document.createElement("div");
      monthYear.style.cssText = `font-weight: 700; font-size: 14px; color: #111827;`;
      monthYear.innerHTML = `${getMonthName2(currentMonth)} ${currentYear} <span style="font-size: 12px; color: #6b7280;">\u25BC</span>`;
      const nextBtn = document.createElement("button");
      nextBtn.innerHTML = "\u2193";
      nextBtn.style.cssText = `
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 8px;
      background: #f3f4f6;
      color: #374151;
      cursor: pointer;
      font-size: 18px;
      font-weight: 700;
      transition: all 0.2s;
    `;
      nextBtn.addEventListener("mouseenter", () => {
        nextBtn.style.background = "#e5e7eb";
      });
      nextBtn.addEventListener("mouseleave", () => {
        nextBtn.style.background = "#f3f4f6";
      });
      nextBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        currentMonth++;
        if (currentMonth > 11) {
          currentMonth = 0;
          currentYear++;
        }
        renderCalendar();
      });
      header.appendChild(prevBtn);
      header.appendChild(monthYear);
      header.appendChild(nextBtn);
      picker.appendChild(header);
      const dayHeaders = document.createElement("div");
      dayHeaders.style.cssText = `display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; margin-bottom: 8px;`;
      ["S", "M", "T", "W", "T", "F", "S"].forEach((day) => {
        const dayHeader = document.createElement("div");
        dayHeader.textContent = day;
        dayHeader.style.cssText = `text-align: center; font-size: 11px; font-weight: 700; color: #6b7280; padding: 4px 0;`;
        dayHeaders.appendChild(dayHeader);
      });
      picker.appendChild(dayHeaders);
      const daysGrid = document.createElement("div");
      daysGrid.style.cssText = `display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px;`;
      const firstDay = getFirstDayOfMonth2(currentYear, currentMonth);
      const daysInMonth = getDaysInMonth2(currentYear, currentMonth);
      const prevMonthDays = currentMonth === 0 ? getDaysInMonth2(currentYear - 1, 11) : getDaysInMonth2(currentYear, currentMonth - 1);
      for (let i = firstDay - 1; i >= 0; i--) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(prevMonthDays - i);
        dayBtn.style.cssText = `width: 100%; aspect-ratio: 1; border: 0; border-radius: 8px; background: transparent; color: #d1d5db; font-size: 12px; cursor: pointer;`;
        daysGrid.appendChild(dayBtn);
      }
      for (let day = 1; day <= daysInMonth; day++) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(day);
        const isToday = day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();
        dayBtn.style.cssText = `
        width: 100%; aspect-ratio: 1; border: 0; border-radius: 8px;
        background: ${isToday ? "#10b981" : "transparent"};
        color: ${isToday ? "white" : "#111827"};
        font-size: 12px; font-weight: ${isToday ? "700" : "500"};
        cursor: pointer; transition: all 0.15s;
      `;
        dayBtn.addEventListener("mouseenter", () => {
          if (!isToday)
            dayBtn.style.background = "#f3f4f6";
        });
        dayBtn.addEventListener("mouseleave", () => {
          if (!isToday)
            dayBtn.style.background = "transparent";
        });
        const selectedDate = new Date(currentYear, currentMonth, day);
        dayBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          onSelect(selectedDate);
          picker.remove();
        });
        daysGrid.appendChild(dayBtn);
      }
      const remainingCells = 42 - (firstDay + daysInMonth);
      for (let i = 1; i <= remainingCells; i++) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(i);
        dayBtn.style.cssText = `width: 100%; aspect-ratio: 1; border: 0; border-radius: 8px; background: transparent; color: #d1d5db; font-size: 12px; cursor: pointer;`;
        daysGrid.appendChild(dayBtn);
      }
      picker.appendChild(daysGrid);
      const footer = document.createElement("div");
      footer.style.cssText = `display: flex; justify-content: space-between; margin-top: 12px; padding-top: 10px; border-top: 1px solid #e5e7eb;`;
      const clearBtn = document.createElement("button");
      clearBtn.textContent = "Clear";
      clearBtn.style.cssText = `padding: 6px 12px; border: 0; border-radius: 6px; background: transparent; color: #10b981; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;`;
      clearBtn.addEventListener("mouseenter", () => {
        clearBtn.style.background = "#d1fae5";
      });
      clearBtn.addEventListener("mouseleave", () => {
        clearBtn.style.background = "transparent";
      });
      clearBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const input = document.getElementById(inputId);
        if (input)
          input.value = "";
        picker.remove();
      });
      const todayBtn = document.createElement("button");
      todayBtn.textContent = "Today";
      todayBtn.style.cssText = `padding: 6px 12px; border: 0; border-radius: 6px; background: transparent; color: #10b981; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;`;
      todayBtn.addEventListener("mouseenter", () => {
        todayBtn.style.background = "#d1fae5";
      });
      todayBtn.addEventListener("mouseleave", () => {
        todayBtn.style.background = "transparent";
      });
      todayBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        onSelect(today);
        picker.remove();
      });
      footer.appendChild(clearBtn);
      footer.appendChild(todayBtn);
      picker.appendChild(footer);
    }
    renderCalendar();
    return picker;
  }
  function parseDate2(dateStr) {
    const parts = dateStr.split("/");
    if (parts.length !== 3)
      return null;
    const month = parseInt(parts[0], 10) - 1;
    const day = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);
    if (isNaN(month) || isNaN(day) || isNaN(year))
      return null;
    const date = new Date(year, month, day);
    if (date.getFullYear() !== year || date.getMonth() !== month || date.getDate() !== day) {
      return null;
    }
    return date;
  }
  function addDays2(date, days) {
    const result = new Date(date);
    result.setDate(result.getDate() + days);
    return result;
  }
  function calculateStemFilingWindow(currentOptEndDate) {
    const earliestStart = addDays2(currentOptEndDate, -90);
    const latestEnd = currentOptEndDate;
    return {
      earliestStart,
      latestEnd,
      currentOptEndDate
    };
  }
  async function loadSavedData2() {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
        method: "GET",
        credentials: "include",
        // Send cookies from website
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
            method: "GET",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            }
          });
        }
      }
      if (!response.ok)
        return null;
      const result = await response.json();
      return result.ok ? result.data : null;
    } catch (error) {
      return null;
    }
  }
  async function saveOptEadEndDate(optEadEndDate) {
    try {
      const existingData = await loadSavedData2();
      const payload = {
        program_end_date: existingData?.program_end_date || null,
        dso_recommendation_date: existingData?.dso_recommendation_date || null,
        opt_start_date: existingData?.opt_start_date || null,
        opt_ead_end_date: optEadEndDate,
        stem_start_date: existingData?.stem_start_date || null,
        _lastModifiedField: "opt_ead_end_date"
        // Tell API this field was updated
      };
      const { idToken } = await chrome.storage.sync.get("idToken");
      if (idToken) {
        const response2 = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${idToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(payload)
        });
        if (response2.ok) {
          const result2 = await response2.json();
          return result2.ok === true;
        }
      }
      const response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const result = await response.json();
      return result.ok === true;
    } catch (error) {
      return false;
    }
  }
  function renderStemApply(root, onBack) {
    root.innerHTML = "";
    renderPageHeader(root, "STEM OPT Dates", "Calculate your STEM OPT extension filing window");
    const content = document.createElement("div");
    content.style.cssText = "margin-top: 12px;";
    const infoCard = document.createElement("div");
    infoCard.style.cssText = `
    padding: 14px;
    border-radius: 14px;
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
    margin-bottom: 12px;
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);
  `;
    infoCard.innerHTML = `
    <div style="display: flex; gap: 10px; align-items: start;">
      <div style="flex-shrink: 0; width: 28px; height: 28px; border-radius: 50%; background: rgba(255,255,255,0.2); display: grid; place-items: center; font-size: 16px;">
        \u2139\uFE0F
      </div>
      <div>
        <div style="font-weight: 700; font-size: 13px; margin-bottom: 6px;">STEM OPT Extension Rules</div>
        <div style="font-size: 12px; line-height: 1.5; opacity: 0.95;">
          Apply up to 90 days before your current OPT expires. If filed timely, you get automatic 180-day work authorization while your application is pending.
        </div>
      </div>
    </div>
  `;
    content.appendChild(infoCard);
    const optEndCard = document.createElement("div");
    optEndCard.style.cssText = `
    padding: 14px;
    border-radius: 14px;
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
    margin-bottom: 12px;
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.25);
    position: relative;
  `;
    optEndCard.innerHTML = `
    <div style="display: flex; gap: 10px; align-items: start; margin-bottom: 10px;">
      <div style="flex-shrink: 0; width: 36px; height: 36px; border-radius: 10px; background: rgba(255,255,255,0.2); display: grid; place-items: center; font-size: 18px;">
        \u{1F5D3}\uFE0F
      </div>
      <div style="flex: 1;">
        <div style="font-weight: 700; font-size: 14px; margin-bottom: 2px;">Current OPT EAD End Date</div>
        <div style="font-size: 11px; opacity: 0.9;">From your OPT Employment Authorization Document</div>
      </div>
    </div>
    <div style="position: relative;">
      <input 
        type="text" 
        id="current-opt-end-date" 
        placeholder="mm/dd/yyyy"
        style="
          width: 100%;
          padding: 10px 40px 10px 12px;
          border: 0;
          border-radius: 10px;
          background: rgba(255,255,255,0.15);
          backdrop-filter: blur(10px);
          color: white;
          font-size: 14px;
          outline: none;
          font-family: inherit;
        "
      />
      <button 
        id="opt-end-date-picker-btn"
        style="
          position: absolute;
          right: 8px;
          top: 50%;
          transform: translateY(-50%);
          width: 32px;
          height: 32px;
          border: 0;
          border-radius: 8px;
          background: rgba(255,255,255,0.2);
          color: white;
          cursor: pointer;
          font-size: 16px;
          display: grid;
          place-items: center;
          transition: all 0.2s;
        "
      >\u{1F5D3}\uFE0F</button>
    </div>
  `;
    content.appendChild(optEndCard);
    const calculateBtn = document.createElement("button");
    calculateBtn.textContent = "Calculate Filing Window";
    calculateBtn.style.cssText = `
    width: 100%;
    padding: 14px;
    border: 0;
    border-radius: 12px;
    background: linear-gradient(135deg, #374151, #1f2937);
    color: white;
    font-weight: 700;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    font-family: inherit;
  `;
    content.appendChild(calculateBtn);
    root.appendChild(content);
    const optEndDatePickerBtn = document.getElementById("opt-end-date-picker-btn");
    let activePicker = null;
    document.addEventListener("click", (e) => {
      if (activePicker && !activePicker.contains(e.target)) {
        const isPickerButton = optEndDatePickerBtn?.contains(e.target);
        if (!isPickerButton) {
          activePicker.remove();
          activePicker = null;
        }
      }
    });
    optEndDatePickerBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (activePicker) {
        activePicker.remove();
        activePicker = null;
      }
      const picker = createDatePicker2("current-opt-end-date", (date) => {
        const input = document.getElementById("current-opt-end-date");
        if (input) {
          input.value = formatDate2(date);
        }
        activePicker = null;
      });
      const container = optEndDatePickerBtn.closest('div[style*="position: relative"]');
      if (container) {
        container.appendChild(picker);
        activePicker = picker;
      }
    });
    if (optEndDatePickerBtn) {
      optEndDatePickerBtn.addEventListener("mouseenter", () => {
        optEndDatePickerBtn.style.background = "rgba(255,255,255,0.3)";
      });
      optEndDatePickerBtn.addEventListener("mouseleave", () => {
        optEndDatePickerBtn.style.background = "rgba(255,255,255,0.2)";
      });
    }
    calculateBtn.addEventListener("click", async () => {
      const optEndInput2 = document.getElementById("current-opt-end-date");
      const currentOptEndDate = parseDate2(optEndInput2.value);
      if (!currentOptEndDate) {
        alert("\u274C Please enter a valid Current OPT EAD End Date (mm/dd/yyyy)");
        return;
      }
      await saveOptEadEndDate(formatDate2(currentOptEndDate));
      const results = calculateStemFilingWindow(currentOptEndDate);
      const { renderStemCountdown: renderStemCountdown2 } = await Promise.resolve().then(() => (init_stem_countdown(), stem_countdown_exports));
      renderStemCountdown2(root, onBack, results);
    });
    const optEndInput = document.getElementById("current-opt-end-date");
    if (optEndInput) {
      addDateInputValidation2(optEndInput);
      optEndInput.addEventListener("focus", (e) => {
        e.target.style.background = "rgba(255,255,255,0.25)";
      });
      optEndInput.addEventListener("blur", async (e) => {
        e.target.style.background = "rgba(255,255,255,0.15)";
        const date = parseDate2(optEndInput.value);
        if (date) {
          await saveOptEadEndDate(formatDate2(date));
        }
      });
    }
    calculateBtn.addEventListener("mouseenter", () => {
      calculateBtn.style.transform = "translateY(-1px)";
      calculateBtn.style.boxShadow = "0 6px 16px rgba(0, 0, 0, 0.2)";
    });
    calculateBtn.addEventListener("mouseleave", () => {
      calculateBtn.style.transform = "translateY(0)";
      calculateBtn.style.boxShadow = "0 4px 12px rgba(0, 0, 0, 0.15)";
    });
    loadSavedData2().then((savedData) => {
      if (savedData && optEndInput && savedData.opt_ead_end_date) {
        optEndInput.value = savedData.opt_ead_end_date;
      }
    });
    setupPageHandlers(onBack);
  }

  // src/pages/clock.ts
  init_config();
  init_navigation();
  function formatDate3(date) {
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  }
  function validateDateInput3(input) {
    let cleaned = input.replace(/[^\d/]/g, "");
    cleaned = cleaned.substring(0, 10);
    const parts = cleaned.split("/");
    if (parts.length >= 1 && parts[0].length > 0) {
      let month = parseInt(parts[0]);
      if (month > 12) {
        parts[0] = "12";
      } else if (parts[0].length === 2 && month === 0) {
        parts[0] = "01";
      }
      parts[0] = parts[0].substring(0, 2);
    }
    if (parts.length >= 2 && parts[1].length > 0) {
      let month = parseInt(parts[0]) || 1;
      let day = parseInt(parts[1]);
      const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      const maxDay = daysInMonth[month - 1] || 31;
      if (day > maxDay) {
        parts[1] = String(maxDay).padStart(2, "0");
      } else if (parts[1].length === 2 && day === 0) {
        parts[1] = "01";
      }
      parts[1] = parts[1].substring(0, 2);
    }
    if (parts.length >= 3) {
      parts[2] = parts[2].substring(0, 4);
    }
    return parts.join("/");
  }
  function addDateInputValidation3(inputElement) {
    inputElement.addEventListener("input", (e) => {
      const target = e.target;
      const cursorPosition = target.selectionStart || 0;
      const oldValue = target.value;
      const newValue = validateDateInput3(oldValue);
      if (newValue !== oldValue) {
        target.value = newValue;
        target.setSelectionRange(cursorPosition, cursorPosition);
      }
    });
    inputElement.addEventListener("keypress", (e) => {
      const char = e.key;
      if (!/[\d/]/.test(char) && !["Backspace", "Delete", "ArrowLeft", "ArrowRight", "Tab"].includes(e.key)) {
        e.preventDefault();
      }
    });
  }
  function getMonthName3(month) {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ];
    return months[month];
  }
  function getDaysInMonth3(year, month) {
    return new Date(year, month + 1, 0).getDate();
  }
  function getFirstDayOfMonth3(year, month) {
    return new Date(year, month, 1).getDay();
  }
  function createDatePicker3(inputId, onSelect) {
    const today = /* @__PURE__ */ new Date();
    let currentYear = today.getFullYear();
    let currentMonth = today.getMonth();
    const picker = document.createElement("div");
    picker.style.cssText = `
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    margin-top: 8px;
    background: white;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
    padding: 14px;
    z-index: 1000;
    animation: slideDown 0.2s ease;
  `;
    const style = document.createElement("style");
    style.textContent = `
    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
    document.head.appendChild(style);
    function renderCalendar() {
      picker.innerHTML = "";
      const header = document.createElement("div");
      header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      padding-bottom: 10px;
      border-bottom: 2px solid #e5e7eb;
    `;
      const prevBtn = document.createElement("button");
      prevBtn.innerHTML = "\u2191";
      prevBtn.style.cssText = `
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 8px;
      background: #f3f4f6;
      color: #374151;
      cursor: pointer;
      font-size: 18px;
      font-weight: 700;
      transition: all 0.2s;
    `;
      prevBtn.addEventListener("mouseenter", () => {
        prevBtn.style.background = "#e5e7eb";
      });
      prevBtn.addEventListener("mouseleave", () => {
        prevBtn.style.background = "#f3f4f6";
      });
      prevBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        currentMonth--;
        if (currentMonth < 0) {
          currentMonth = 11;
          currentYear--;
        }
        renderCalendar();
      });
      const monthYear = document.createElement("div");
      monthYear.style.cssText = `font-weight: 700; font-size: 14px; color: #111827;`;
      monthYear.innerHTML = `${getMonthName3(currentMonth)} ${currentYear} <span style="font-size: 12px; color: #6b7280;">\u25BC</span>`;
      const nextBtn = document.createElement("button");
      nextBtn.innerHTML = "\u2193";
      nextBtn.style.cssText = `
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 8px;
      background: #f3f4f6;
      color: #374151;
      cursor: pointer;
      font-size: 18px;
      font-weight: 700;
      transition: all 0.2s;
    `;
      nextBtn.addEventListener("mouseenter", () => {
        nextBtn.style.background = "#e5e7eb";
      });
      nextBtn.addEventListener("mouseleave", () => {
        nextBtn.style.background = "#f3f4f6";
      });
      nextBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        currentMonth++;
        if (currentMonth > 11) {
          currentMonth = 0;
          currentYear++;
        }
        renderCalendar();
      });
      header.appendChild(prevBtn);
      header.appendChild(monthYear);
      header.appendChild(nextBtn);
      picker.appendChild(header);
      const dayHeaders = document.createElement("div");
      dayHeaders.style.cssText = `display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; margin-bottom: 8px;`;
      ["S", "M", "T", "W", "T", "F", "S"].forEach((day) => {
        const dayHeader = document.createElement("div");
        dayHeader.textContent = day;
        dayHeader.style.cssText = `text-align: center; font-size: 11px; font-weight: 700; color: #6b7280; padding: 4px 0;`;
        dayHeaders.appendChild(dayHeader);
      });
      picker.appendChild(dayHeaders);
      const daysGrid = document.createElement("div");
      daysGrid.style.cssText = `display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px;`;
      const firstDay = getFirstDayOfMonth3(currentYear, currentMonth);
      const daysInMonth = getDaysInMonth3(currentYear, currentMonth);
      const prevMonthDays = currentMonth === 0 ? getDaysInMonth3(currentYear - 1, 11) : getDaysInMonth3(currentYear, currentMonth - 1);
      for (let i = firstDay - 1; i >= 0; i--) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(prevMonthDays - i);
        dayBtn.style.cssText = `width: 100%; aspect-ratio: 1; border: 0; border-radius: 8px; background: transparent; color: #d1d5db; font-size: 12px; cursor: pointer;`;
        daysGrid.appendChild(dayBtn);
      }
      for (let day = 1; day <= daysInMonth; day++) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(day);
        const isToday = day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();
        dayBtn.style.cssText = `
        width: 100%; aspect-ratio: 1; border: 0; border-radius: 8px;
        background: ${isToday ? "#3b82f6" : "transparent"};
        color: ${isToday ? "white" : "#111827"};
        font-size: 12px; font-weight: ${isToday ? "700" : "500"};
        cursor: pointer; transition: all 0.15s;
      `;
        dayBtn.addEventListener("mouseenter", () => {
          if (!isToday)
            dayBtn.style.background = "#f3f4f6";
        });
        dayBtn.addEventListener("mouseleave", () => {
          if (!isToday)
            dayBtn.style.background = "transparent";
        });
        const selectedDate = new Date(currentYear, currentMonth, day);
        dayBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          onSelect(selectedDate);
          picker.remove();
        });
        daysGrid.appendChild(dayBtn);
      }
      const remainingCells = 42 - (firstDay + daysInMonth);
      for (let i = 1; i <= remainingCells; i++) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(i);
        dayBtn.style.cssText = `width: 100%; aspect-ratio: 1; border: 0; border-radius: 8px; background: transparent; color: #d1d5db; font-size: 12px; cursor: pointer;`;
        daysGrid.appendChild(dayBtn);
      }
      picker.appendChild(daysGrid);
      const footer = document.createElement("div");
      footer.style.cssText = `display: flex; justify-content: space-between; margin-top: 12px; padding-top: 10px; border-top: 1px solid #e5e7eb;`;
      const clearBtn = document.createElement("button");
      clearBtn.textContent = "Clear";
      clearBtn.style.cssText = `padding: 6px 12px; border: 0; border-radius: 6px; background: transparent; color: #3b82f6; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;`;
      clearBtn.addEventListener("mouseenter", () => {
        clearBtn.style.background = "#eff6ff";
      });
      clearBtn.addEventListener("mouseleave", () => {
        clearBtn.style.background = "transparent";
      });
      clearBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const input = document.getElementById(inputId);
        if (input)
          input.value = "";
        picker.remove();
      });
      const todayBtn = document.createElement("button");
      todayBtn.textContent = "Today";
      todayBtn.style.cssText = `padding: 6px 12px; border: 0; border-radius: 6px; background: transparent; color: #3b82f6; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;`;
      todayBtn.addEventListener("mouseenter", () => {
        todayBtn.style.background = "#eff6ff";
      });
      todayBtn.addEventListener("mouseleave", () => {
        todayBtn.style.background = "transparent";
      });
      todayBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        onSelect(today);
        picker.remove();
      });
      footer.appendChild(clearBtn);
      footer.appendChild(todayBtn);
      picker.appendChild(footer);
    }
    renderCalendar();
    return picker;
  }
  function parseDate3(dateStr) {
    const parts = dateStr.split("/");
    if (parts.length !== 3)
      return null;
    const month = parseInt(parts[0], 10) - 1;
    const day = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);
    if (isNaN(month) || isNaN(day) || isNaN(year))
      return null;
    const date = new Date(year, month, day);
    if (date.getFullYear() !== year || date.getMonth() !== month || date.getDate() !== day) {
      return null;
    }
    return date;
  }
  async function loadSavedData3() {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
        method: "GET",
        credentials: "include",
        // Send cookies from website
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
            method: "GET",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            }
          });
        }
      }
      if (!response.ok)
        return null;
      const result = await response.json();
      return result.ok ? result.data : null;
    } catch (error) {
      return null;
    }
  }
  async function saveOptStartDate(optStartDate) {
    try {
      const existingData = await loadSavedData3();
      const payload = {
        program_end_date: existingData?.program_end_date || null,
        dso_recommendation_date: existingData?.dso_recommendation_date || null,
        opt_start_date: optStartDate,
        opt_ead_end_date: existingData?.opt_ead_end_date || null,
        stem_start_date: existingData?.stem_start_date || null,
        _lastModifiedField: "opt_start_date"
        // Tell API this field was updated
      };
      const { idToken } = await chrome.storage.sync.get("idToken");
      if (idToken) {
        const response2 = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${idToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(payload)
        });
        if (response2.ok) {
          const result2 = await response2.json();
          return result2.ok === true;
        }
      }
      const response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const result = await response.json();
      return result.ok === true;
    } catch (error) {
      return false;
    }
  }
  function renderClock(root, onBack) {
    root.innerHTML = "";
    renderPageHeader(root, "OPT Clock Tracker", "Track your OPT timeline with precision");
    const content = document.createElement("div");
    content.style.cssText = "margin-top: 12px;";
    const startDateCard = document.createElement("div");
    startDateCard.style.cssText = `
    padding: 14px;
    border-radius: 16px;
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    color: white;
    margin-bottom: 10px;
    box-shadow: 0 4px 16px rgba(59, 130, 246, 0.3);
    position: relative;
  `;
    startDateCard.innerHTML = `
    <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 10px;">
      <div style="flex-shrink: 0; width: 40px; height: 40px; border-radius: 12px; background: rgba(255,255,255,0.2); display: grid; place-items: center; font-size: 20px;">
        \u{1F5D3}\uFE0F
      </div>
      <div style="flex: 1;">
        <div style="font-weight: 700; font-size: 15px;">Start Date</div>
      </div>
    </div>
    <div style="position: relative;">
      <input 
        type="text" 
        id="opt-start-date" 
        placeholder="mm/dd/yyyy"
        style="
          width: 100%;
          padding: 12px 46px 12px 14px;
          border: 0;
          border-radius: 10px;
          background: rgba(255,255,255,0.2);
          backdrop-filter: blur(10px);
          color: white;
          font-size: 14px;
          font-weight: 600;
          outline: none;
          font-family: inherit;
        "
      />
      <button 
        id="start-date-picker-btn"
        style="
          position: absolute;
          right: 8px;
          top: 50%;
          transform: translateY(-50%);
          width: 32px;
          height: 32px;
          border: 0;
          border-radius: 8px;
          background: rgba(255,255,255,0.25);
          color: white;
          cursor: pointer;
          font-size: 16px;
          display: grid;
          place-items: center;
          transition: all 0.2s;
        "
      >\u{1F5D3}\uFE0F</button>
    </div>
  `;
    content.appendChild(startDateCard);
    const optDaysCard = document.createElement("div");
    optDaysCard.style.cssText = `
    padding: 18px;
    border-radius: 16px;
    background: linear-gradient(135deg, #a855f7, #9333ea);
    color: white;
    margin-bottom: 10px;
    box-shadow: 0 4px 16px rgba(168, 85, 247, 0.3);
    text-align: center;
  `;
    optDaysCard.innerHTML = `
    <div style="font-size: 56px; font-weight: 800; line-height: 1; margin-bottom: 6px;">90</div>
    <div style="font-size: 14px; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 4px;">REGULAR OPT</div>
    <div style="font-size: 11px; opacity: 0.95;">Maximum 90 days of unemployment allowed</div>
  `;
    content.appendChild(optDaysCard);
    const readyMessage = document.createElement("div");
    readyMessage.style.cssText = `
    padding: 14px;
    border-radius: 14px;
    background: linear-gradient(135deg, #10b981, #059669);
    color: white;
    margin-bottom: 10px;
    box-shadow: 0 4px 16px rgba(16, 185, 129, 0.3);
    text-align: center;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.3;
  `;
    readyMessage.textContent = "Ready to track your OPT period!";
    content.appendChild(readyMessage);
    const saveBtn = document.createElement("button");
    saveBtn.innerHTML = `
    <div style="display: flex; align-items: center; justify-content: center; gap: 8px;">
      <span style="font-size: 18px;">\u{1F4BE}</span>
      <span>Save & Go</span>
    </div>
  `;
    saveBtn.style.cssText = `
    width: 100%;
    padding: 14px;
    border: 0;
    border-radius: 14px;
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    color: white;
    font-weight: 800;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 4px 16px rgba(59, 130, 246, 0.3);
    font-family: inherit;
  `;
    content.appendChild(saveBtn);
    root.appendChild(content);
    const startDatePickerBtn = document.getElementById("start-date-picker-btn");
    let activePicker = null;
    document.addEventListener("click", (e) => {
      if (activePicker && !activePicker.contains(e.target)) {
        const isPickerButton = startDatePickerBtn?.contains(e.target);
        if (!isPickerButton) {
          activePicker.remove();
          activePicker = null;
        }
      }
    });
    startDatePickerBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (activePicker) {
        activePicker.remove();
        activePicker = null;
      }
      const picker = createDatePicker3("opt-start-date", (date) => {
        const input = document.getElementById("opt-start-date");
        if (input) {
          input.value = formatDate3(date);
        }
        activePicker = null;
      });
      const container = startDatePickerBtn.closest('div[style*="position: relative"]');
      if (container) {
        container.appendChild(picker);
        activePicker = picker;
      }
    });
    if (startDatePickerBtn) {
      startDatePickerBtn.addEventListener("mouseenter", () => {
        startDatePickerBtn.style.background = "rgba(255,255,255,0.35)";
      });
      startDatePickerBtn.addEventListener("mouseleave", () => {
        startDatePickerBtn.style.background = "rgba(255,255,255,0.25)";
      });
    }
    saveBtn.addEventListener("click", async () => {
      const startDateInput2 = document.getElementById("opt-start-date");
      const optStartDate = parseDate3(startDateInput2.value);
      if (!optStartDate) {
        alert("\u274C Please enter a valid OPT Start Date (mm/dd/yyyy)");
        return;
      }
      await saveOptStartDate(formatDate3(optStartDate));
      const { renderClockTracker: renderClockTracker2 } = await Promise.resolve().then(() => (init_clock_tracker(), clock_tracker_exports));
      renderClockTracker2(root, onBack, optStartDate);
    });
    const startDateInput = document.getElementById("opt-start-date");
    if (startDateInput) {
      addDateInputValidation3(startDateInput);
      startDateInput.addEventListener("focus", (e) => {
        e.target.style.background = "rgba(255,255,255,0.3)";
      });
      startDateInput.addEventListener("blur", async (e) => {
        e.target.style.background = "rgba(255,255,255,0.2)";
        const date = parseDate3(startDateInput.value);
        if (date) {
          await saveOptStartDate(formatDate3(date));
        }
      });
    }
    saveBtn.addEventListener("mouseenter", () => {
      saveBtn.style.transform = "translateY(-2px)";
      saveBtn.style.boxShadow = "0 8px 24px rgba(59, 130, 246, 0.4)";
    });
    saveBtn.addEventListener("mouseleave", () => {
      saveBtn.style.transform = "translateY(0)";
      saveBtn.style.boxShadow = "0 6px 20px rgba(59, 130, 246, 0.3)";
    });
    loadSavedData3().then((savedData) => {
      if (savedData && startDateInput && savedData.opt_start_date) {
        startDateInput.value = savedData.opt_start_date;
      }
    });
    setupPageHandlers(onBack);
  }

  // src/pages/stem-clock.ts
  init_config();
  init_navigation();
  function formatDate4(date) {
    const month = String(date.getMonth() + 1).padStart(2, "0");
    const day = String(date.getDate()).padStart(2, "0");
    const year = date.getFullYear();
    return `${month}/${day}/${year}`;
  }
  function validateDateInput4(input) {
    let cleaned = input.replace(/[^\d/]/g, "");
    cleaned = cleaned.substring(0, 10);
    const parts = cleaned.split("/");
    if (parts.length >= 1 && parts[0].length > 0) {
      let month = parseInt(parts[0]);
      if (month > 12) {
        parts[0] = "12";
      } else if (parts[0].length === 2 && month === 0) {
        parts[0] = "01";
      }
      parts[0] = parts[0].substring(0, 2);
    }
    if (parts.length >= 2 && parts[1].length > 0) {
      let month = parseInt(parts[0]) || 1;
      let day = parseInt(parts[1]);
      const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
      const maxDay = daysInMonth[month - 1] || 31;
      if (day > maxDay) {
        parts[1] = String(maxDay).padStart(2, "0");
      } else if (parts[1].length === 2 && day === 0) {
        parts[1] = "01";
      }
      parts[1] = parts[1].substring(0, 2);
    }
    if (parts.length >= 3) {
      parts[2] = parts[2].substring(0, 4);
    }
    return parts.join("/");
  }
  function addDateInputValidation4(inputElement) {
    inputElement.addEventListener("input", (e) => {
      const target = e.target;
      const cursorPosition = target.selectionStart || 0;
      const oldValue = target.value;
      const newValue = validateDateInput4(oldValue);
      if (newValue !== oldValue) {
        target.value = newValue;
        target.setSelectionRange(cursorPosition, cursorPosition);
      }
    });
    inputElement.addEventListener("keypress", (e) => {
      const char = e.key;
      if (!/[\d/]/.test(char) && !["Backspace", "Delete", "ArrowLeft", "ArrowRight", "Tab"].includes(e.key)) {
        e.preventDefault();
      }
    });
  }
  function getMonthName4(month) {
    const months = [
      "January",
      "February",
      "March",
      "April",
      "May",
      "June",
      "July",
      "August",
      "September",
      "October",
      "November",
      "December"
    ];
    return months[month];
  }
  function getDaysInMonth4(year, month) {
    return new Date(year, month + 1, 0).getDate();
  }
  function getFirstDayOfMonth4(year, month) {
    return new Date(year, month, 1).getDay();
  }
  function createDatePicker4(inputId, onSelect) {
    const today = /* @__PURE__ */ new Date();
    let currentYear = today.getFullYear();
    let currentMonth = today.getMonth();
    const picker = document.createElement("div");
    picker.style.cssText = `
    position: absolute;
    top: 100%;
    left: 0;
    right: 0;
    margin-top: 8px;
    background: white;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.25);
    padding: 14px;
    z-index: 1000;
    animation: slideDown 0.2s ease;
  `;
    const style = document.createElement("style");
    style.textContent = `
    @keyframes slideDown {
      from { opacity: 0; transform: translateY(-8px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
    document.head.appendChild(style);
    function renderCalendar() {
      picker.innerHTML = "";
      const header = document.createElement("div");
      header.style.cssText = `
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 12px;
      padding-bottom: 10px;
      border-bottom: 2px solid #e5e7eb;
    `;
      const prevBtn = document.createElement("button");
      prevBtn.innerHTML = "\u2191";
      prevBtn.style.cssText = `
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 8px;
      background: #f3f4f6;
      color: #374151;
      cursor: pointer;
      font-size: 18px;
      font-weight: 700;
      transition: all 0.2s;
    `;
      prevBtn.addEventListener("mouseenter", () => {
        prevBtn.style.background = "#e5e7eb";
      });
      prevBtn.addEventListener("mouseleave", () => {
        prevBtn.style.background = "#f3f4f6";
      });
      prevBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        currentMonth--;
        if (currentMonth < 0) {
          currentMonth = 11;
          currentYear--;
        }
        renderCalendar();
      });
      const monthYear = document.createElement("div");
      monthYear.style.cssText = `font-weight: 700; font-size: 14px; color: #111827;`;
      monthYear.innerHTML = `${getMonthName4(currentMonth)} ${currentYear} <span style="font-size: 12px; color: #6b7280;">\u25BC</span>`;
      const nextBtn = document.createElement("button");
      nextBtn.innerHTML = "\u2193";
      nextBtn.style.cssText = `
      width: 32px;
      height: 32px;
      border: 0;
      border-radius: 8px;
      background: #f3f4f6;
      color: #374151;
      cursor: pointer;
      font-size: 18px;
      font-weight: 700;
      transition: all 0.2s;
    `;
      nextBtn.addEventListener("mouseenter", () => {
        nextBtn.style.background = "#e5e7eb";
      });
      nextBtn.addEventListener("mouseleave", () => {
        nextBtn.style.background = "#f3f4f6";
      });
      nextBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        currentMonth++;
        if (currentMonth > 11) {
          currentMonth = 0;
          currentYear++;
        }
        renderCalendar();
      });
      header.appendChild(prevBtn);
      header.appendChild(monthYear);
      header.appendChild(nextBtn);
      picker.appendChild(header);
      const dayHeaders = document.createElement("div");
      dayHeaders.style.cssText = `display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px; margin-bottom: 8px;`;
      ["S", "M", "T", "W", "T", "F", "S"].forEach((day) => {
        const dayHeader = document.createElement("div");
        dayHeader.textContent = day;
        dayHeader.style.cssText = `text-align: center; font-size: 11px; font-weight: 700; color: #6b7280; padding: 4px 0;`;
        dayHeaders.appendChild(dayHeader);
      });
      picker.appendChild(dayHeaders);
      const daysGrid = document.createElement("div");
      daysGrid.style.cssText = `display: grid; grid-template-columns: repeat(7, 1fr); gap: 4px;`;
      const firstDay = getFirstDayOfMonth4(currentYear, currentMonth);
      const daysInMonth = getDaysInMonth4(currentYear, currentMonth);
      const prevMonthDays = currentMonth === 0 ? getDaysInMonth4(currentYear - 1, 11) : getDaysInMonth4(currentYear, currentMonth - 1);
      for (let i = firstDay - 1; i >= 0; i--) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(prevMonthDays - i);
        dayBtn.style.cssText = `width: 100%; aspect-ratio: 1; border: 0; border-radius: 8px; background: transparent; color: #d1d5db; font-size: 12px; cursor: pointer;`;
        daysGrid.appendChild(dayBtn);
      }
      for (let day = 1; day <= daysInMonth; day++) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(day);
        const isToday = day === today.getDate() && currentMonth === today.getMonth() && currentYear === today.getFullYear();
        dayBtn.style.cssText = `
        width: 100%; aspect-ratio: 1; border: 0; border-radius: 8px;
        background: ${isToday ? "#f97316" : "transparent"};
        color: ${isToday ? "white" : "#111827"};
        font-size: 12px; font-weight: ${isToday ? "700" : "500"};
        cursor: pointer; transition: all 0.15s;
      `;
        dayBtn.addEventListener("mouseenter", () => {
          if (!isToday)
            dayBtn.style.background = "#f3f4f6";
        });
        dayBtn.addEventListener("mouseleave", () => {
          if (!isToday)
            dayBtn.style.background = "transparent";
        });
        const selectedDate = new Date(currentYear, currentMonth, day);
        dayBtn.addEventListener("click", (e) => {
          e.stopPropagation();
          onSelect(selectedDate);
          picker.remove();
        });
        daysGrid.appendChild(dayBtn);
      }
      const remainingCells = 42 - (firstDay + daysInMonth);
      for (let i = 1; i <= remainingCells; i++) {
        const dayBtn = document.createElement("button");
        dayBtn.textContent = String(i);
        dayBtn.style.cssText = `width: 100%; aspect-ratio: 1; border: 0; border-radius: 8px; background: transparent; color: #d1d5db; font-size: 12px; cursor: pointer;`;
        daysGrid.appendChild(dayBtn);
      }
      picker.appendChild(daysGrid);
      const footer = document.createElement("div");
      footer.style.cssText = `display: flex; justify-content: space-between; margin-top: 12px; padding-top: 10px; border-top: 1px solid #e5e7eb;`;
      const clearBtn = document.createElement("button");
      clearBtn.textContent = "Clear";
      clearBtn.style.cssText = `padding: 6px 12px; border: 0; border-radius: 6px; background: transparent; color: #f97316; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;`;
      clearBtn.addEventListener("mouseenter", () => {
        clearBtn.style.background = "#fff7ed";
      });
      clearBtn.addEventListener("mouseleave", () => {
        clearBtn.style.background = "transparent";
      });
      clearBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        const input = document.getElementById(inputId);
        if (input)
          input.value = "";
        picker.remove();
      });
      const todayBtn = document.createElement("button");
      todayBtn.textContent = "Today";
      todayBtn.style.cssText = `padding: 6px 12px; border: 0; border-radius: 6px; background: transparent; color: #f97316; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.2s;`;
      todayBtn.addEventListener("mouseenter", () => {
        todayBtn.style.background = "#fff7ed";
      });
      todayBtn.addEventListener("mouseleave", () => {
        todayBtn.style.background = "transparent";
      });
      todayBtn.addEventListener("click", (e) => {
        e.stopPropagation();
        onSelect(today);
        picker.remove();
      });
      footer.appendChild(clearBtn);
      footer.appendChild(todayBtn);
      picker.appendChild(footer);
    }
    renderCalendar();
    return picker;
  }
  function parseDate4(dateStr) {
    const parts = dateStr.split("/");
    if (parts.length !== 3)
      return null;
    const month = parseInt(parts[0], 10) - 1;
    const day = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);
    if (isNaN(month) || isNaN(day) || isNaN(year))
      return null;
    const date = new Date(year, month, day);
    if (date.getFullYear() !== year || date.getMonth() !== month || date.getDate() !== day) {
      return null;
    }
    return date;
  }
  async function loadSavedData4() {
    try {
      let response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
        method: "GET",
        credentials: "include",
        // Send cookies from website
        headers: {
          "Content-Type": "application/json"
        }
      });
      if (!response.ok) {
        const { idToken } = await chrome.storage.sync.get("idToken");
        if (idToken) {
          response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
            method: "GET",
            headers: {
              "Authorization": `Bearer ${idToken}`,
              "Content-Type": "application/json"
            }
          });
        }
      }
      if (!response.ok)
        return null;
      const result = await response.json();
      return result.ok ? result.data : null;
    } catch (error) {
      return null;
    }
  }
  async function saveStemEadStartDate(stemEadStartDate) {
    try {
      const existingData = await loadSavedData4();
      const payload = {
        program_end_date: existingData?.program_end_date || null,
        dso_recommendation_date: existingData?.dso_recommendation_date || null,
        opt_start_date: existingData?.opt_start_date || null,
        opt_ead_end_date: existingData?.opt_ead_end_date || null,
        stem_start_date: stemEadStartDate,
        _lastModifiedField: "stem_start_date"
        // Tell API this field was updated
      };
      const { idToken } = await chrome.storage.sync.get("idToken");
      if (idToken) {
        const response2 = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
          method: "POST",
          headers: {
            "Authorization": `Bearer ${idToken}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify(payload)
        });
        if (response2.ok) {
          const result2 = await response2.json();
          return result2.ok === true;
        }
      }
      const response = await fetch(`${WEBSITE_URL}/api/opt/calculator`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(payload)
      });
      const result = await response.json();
      return result.ok === true;
    } catch (error) {
      return false;
    }
  }
  function renderStemClock(root, onBack) {
    root.innerHTML = "";
    renderPageHeader(root, "STEM OPT Clock Tracker", "Track your STEM OPT timeline with precision");
    const content = document.createElement("div");
    content.style.cssText = "margin-top: 12px;";
    const startDateCard = document.createElement("div");
    startDateCard.style.cssText = `
    padding: 14px;
    border-radius: 16px;
    background: linear-gradient(135deg, #f97316, #ea580c);
    color: white;
    margin-bottom: 10px;
    box-shadow: 0 4px 16px rgba(249, 115, 22, 0.3);
    position: relative;
  `;
    startDateCard.innerHTML = `
    <div style="display: flex; gap: 10px; align-items: center; margin-bottom: 10px;">
      <div style="flex-shrink: 0; width: 40px; height: 40px; border-radius: 12px; background: rgba(255,255,255,0.2); display: grid; place-items: center; font-size: 20px;">
        \u{1F5D3}\uFE0F
      </div>
      <div style="flex: 1;">
        <div style="font-weight: 700; font-size: 15px;">STEM EAD Start Date</div>
      </div>
    </div>
    <div style="position: relative;">
      <input 
        type="text" 
        id="stem-ead-start-date" 
        placeholder="mm/dd/yyyy"
        style="
          width: 100%;
          padding: 12px 46px 12px 14px;
          border: 0;
          border-radius: 10px;
          background: rgba(255,255,255,0.2);
          backdrop-filter: blur(10px);
          color: white;
          font-size: 14px;
          font-weight: 600;
          outline: none;
          font-family: inherit;
        "
      />
      <button 
        id="stem-start-date-picker-btn"
        style="
          position: absolute;
          right: 8px;
          top: 50%;
          transform: translateY(-50%);
          width: 32px;
          height: 32px;
          border: 0;
          border-radius: 8px;
          background: rgba(255,255,255,0.25);
          color: white;
          cursor: pointer;
          font-size: 16px;
          display: grid;
          place-items: center;
          transition: all 0.2s;
        "
      >\u{1F5D3}\uFE0F</button>
    </div>
  `;
    content.appendChild(startDateCard);
    const optDaysCard = document.createElement("div");
    optDaysCard.style.cssText = `
    padding: 18px;
    border-radius: 16px;
    background: linear-gradient(135deg, #22c55e, #16a34a);
    color: white;
    margin-bottom: 10px;
    box-shadow: 0 4px 16px rgba(34, 197, 94, 0.3);
    text-align: center;
  `;
    optDaysCard.innerHTML = `
    <div style="font-size: 56px; font-weight: 800; line-height: 1; margin-bottom: 6px;">60</div>
    <div style="font-size: 14px; font-weight: 700; letter-spacing: 0.5px; margin-bottom: 4px;">TOTAL UNEMPLOYMENT DAYS</div>
    <div style="font-size: 11px; opacity: 0.95;">60 days for STEM OPT</div>
  `;
    content.appendChild(optDaysCard);
    const readyMessage = document.createElement("div");
    readyMessage.style.cssText = `
    padding: 14px;
    border-radius: 14px;
    background: linear-gradient(135deg, #3b82f6, #2563eb);
    color: white;
    margin-bottom: 10px;
    box-shadow: 0 4px 16px rgba(59, 130, 246, 0.3);
    text-align: center;
    font-size: 13px;
    font-weight: 700;
    line-height: 1.3;
  `;
    readyMessage.textContent = "Ready to track your STEM OPT unemployment period!";
    content.appendChild(readyMessage);
    const saveBtn = document.createElement("button");
    saveBtn.innerHTML = `
    <div style="display: flex; align-items: center; justify-content: center; gap: 8px;">
      <span style="font-size: 18px;">\u{1F4BE}</span>
      <span>Save & Go</span>
    </div>
  `;
    saveBtn.style.cssText = `
    width: 100%;
    padding: 14px;
    border: 0;
    border-radius: 14px;
    background: linear-gradient(135deg, #f97316, #ea580c);
    color: white;
    font-weight: 800;
    font-size: 14px;
    cursor: pointer;
    transition: all 0.2s ease;
    box-shadow: 0 4px 16px rgba(249, 115, 22, 0.3);
    font-family: inherit;
  `;
    content.appendChild(saveBtn);
    root.appendChild(content);
    const startDatePickerBtn = document.getElementById("stem-start-date-picker-btn");
    let activePicker = null;
    document.addEventListener("click", (e) => {
      if (activePicker && !activePicker.contains(e.target)) {
        const isPickerButton = startDatePickerBtn?.contains(e.target);
        if (!isPickerButton) {
          activePicker.remove();
          activePicker = null;
        }
      }
    });
    startDatePickerBtn?.addEventListener("click", (e) => {
      e.stopPropagation();
      if (activePicker) {
        activePicker.remove();
        activePicker = null;
      }
      const picker = createDatePicker4("stem-ead-start-date", (date) => {
        const input = document.getElementById("stem-ead-start-date");
        if (input) {
          input.value = formatDate4(date);
        }
        activePicker = null;
      });
      const container = startDatePickerBtn.closest('div[style*="position: relative"]');
      if (container) {
        container.appendChild(picker);
        activePicker = picker;
      }
    });
    if (startDatePickerBtn) {
      startDatePickerBtn.addEventListener("mouseenter", () => {
        startDatePickerBtn.style.background = "rgba(255,255,255,0.35)";
      });
      startDatePickerBtn.addEventListener("mouseleave", () => {
        startDatePickerBtn.style.background = "rgba(255,255,255,0.25)";
      });
    }
    saveBtn.addEventListener("click", async () => {
      const startDateInput2 = document.getElementById("stem-ead-start-date");
      const stemEadStartDate = parseDate4(startDateInput2.value);
      if (!stemEadStartDate) {
        alert("\u274C Please enter a valid STEM EAD Start Date (mm/dd/yyyy)");
        return;
      }
      await saveStemEadStartDate(formatDate4(stemEadStartDate));
      const { renderStemClockTracker: renderStemClockTracker2 } = await Promise.resolve().then(() => (init_stem_clock_tracker(), stem_clock_tracker_exports));
      renderStemClockTracker2(root, onBack, stemEadStartDate);
    });
    const startDateInput = document.getElementById("stem-ead-start-date");
    if (startDateInput) {
      addDateInputValidation4(startDateInput);
      startDateInput.addEventListener("focus", (e) => {
        e.target.style.background = "rgba(255,255,255,0.3)";
      });
      startDateInput.addEventListener("blur", async (e) => {
        e.target.style.background = "rgba(255,255,255,0.2)";
        const date = parseDate4(startDateInput.value);
        if (date) {
          await saveStemEadStartDate(formatDate4(date));
        }
      });
    }
    saveBtn.addEventListener("mouseenter", () => {
      saveBtn.style.transform = "translateY(-2px)";
      saveBtn.style.boxShadow = "0 8px 24px rgba(249, 115, 22, 0.4)";
    });
    saveBtn.addEventListener("mouseleave", () => {
      saveBtn.style.transform = "translateY(0)";
      saveBtn.style.boxShadow = "0 6px 20px rgba(249, 115, 22, 0.3)";
    });
    loadSavedData4().then((savedData) => {
      if (savedData && startDateInput && savedData.stem_start_date) {
        startDateInput.value = savedData.stem_start_date;
      }
    });
    setupPageHandlers(onBack);
  }

  // src/popup.ts
  init_navigation();
  async function isSignedIn() {
    try {
      const response = await fetch("https://www.trackmyopt.com/api/me", {
        method: "GET",
        credentials: "include",
        headers: { "Content-Type": "application/json" }
      });
      if (response.ok) {
        await chrome.storage.sync.set({ signedIn: true });
        return true;
      } else {
        await chrome.storage.sync.set({ signedIn: false });
        return false;
      }
    } catch {
      return false;
    }
  }
  async function applyTheme() {
    const { theme } = await chrome.storage.sync.get("theme");
    if (theme === "dark") {
      document.body.classList.add("dark-mode");
      document.body.classList.remove("light-mode");
    } else {
      document.body.classList.remove("dark-mode");
      document.body.classList.remove("light-mode");
    }
  }
  async function navigateToPage(page, data) {
    const root = document.getElementById("root");
    if (!root)
      return;
    switch (page) {
      case "opt-apply":
        setCurrentPage("opt-apply");
        renderOptApply(root, () => navigateToPage("home"));
        break;
      case "stem-apply":
        setCurrentPage("stem-apply");
        renderStemApply(root, () => navigateToPage("home"));
        break;
      case "clock":
        setCurrentPage("clock");
        renderClock(root, () => navigateToPage("home"));
        break;
      case "stem-clock":
        setCurrentPage("stem-clock");
        renderStemClock(root, () => navigateToPage("home"));
        break;
      case "opt-countdown":
        if (data && data.results) {
          setCurrentPage("opt-countdown");
          const { renderOptCountdown: renderOptCountdown2 } = await Promise.resolve().then(() => (init_opt_countdown(), opt_countdown_exports));
          const results = {
            earliestStart: new Date(data.results.earliestStart),
            latestEnd: new Date(data.results.latestEnd),
            uscisDeadline: data.results.uscisDeadline ? new Date(data.results.uscisDeadline) : null,
            programEndDate: new Date(data.results.programEndDate)
          };
          renderOptCountdown2(root, () => navigateToPage("opt-apply"), results);
        } else {
          navigateToPage("opt-apply");
        }
        break;
      case "stem-countdown":
        if (data && data.results) {
          setCurrentPage("stem-countdown");
          const { renderStemCountdown: renderStemCountdown2 } = await Promise.resolve().then(() => (init_stem_countdown(), stem_countdown_exports));
          const results = {
            earliestStart: new Date(data.results.earliestStart),
            latestEnd: new Date(data.results.latestEnd),
            currentOptEndDate: new Date(data.results.currentOptEndDate)
          };
          renderStemCountdown2(root, () => navigateToPage("stem-apply"), results);
        } else {
          navigateToPage("stem-apply");
        }
        break;
      case "clock-tracker":
        if (data && data.startDate) {
          setCurrentPage("clock-tracker");
          const { renderClockTracker: renderClockTracker2 } = await Promise.resolve().then(() => (init_clock_tracker(), clock_tracker_exports));
          const startDate = new Date(data.startDate);
          renderClockTracker2(root, () => navigateToPage("clock"), startDate);
        } else {
          navigateToPage("clock");
        }
        break;
      case "stem-clock-tracker":
        if (data && data.startDate) {
          setCurrentPage("stem-clock-tracker");
          const { renderStemClockTracker: renderStemClockTracker2 } = await Promise.resolve().then(() => (init_stem_clock_tracker(), stem_clock_tracker_exports));
          const startDate = new Date(data.startDate);
          renderStemClockTracker2(root, () => navigateToPage("stem-clock"), startDate);
        } else {
          navigateToPage("stem-clock");
        }
        break;
      case "home":
      default:
        setCurrentPage("home");
        renderHome(root, navigateToPage);
        break;
    }
  }
  async function render() {
    const root = document.getElementById("root");
    if (!root)
      return;
    await applyTheme();
    const signedIn = await isSignedIn();
    if (signedIn) {
      const lastPage = await getLastPage();
      if (lastPage && lastPage !== "home") {
        const pageData = await getPageData(lastPage);
        await navigateToPage(lastPage, pageData);
      } else {
        await navigateToPage("home");
      }
    } else {
      renderLocked(root);
    }
  }
  document.addEventListener("DOMContentLoaded", () => {
    render();
  });
  chrome.storage.onChanged.addListener((changes, areaName) => {
    if (areaName === "sync" && changes.signedIn) {
      render();
    }
  });
})();
