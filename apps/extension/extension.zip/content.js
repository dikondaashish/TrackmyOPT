"use strict";
(() => {
  // src/content.ts
  function getExtensionVersion() {
    try {
      return chrome.runtime.getManifest().version;
    } catch (error) {
      console.warn("[TrackMyOPT] Extension context invalidated, please refresh the page");
      return null;
    }
  }
  function markExtensionConnected() {
    try {
      const version = getExtensionVersion();
      if (!version)
        return;
      localStorage.setItem("tmo_extension_connected", "true");
      localStorage.setItem("tmo_extension_version", version);
      localStorage.setItem("tmo_extension_last_sync", (/* @__PURE__ */ new Date()).toISOString());
    } catch (error) {
      console.warn("[TrackMyOPT] Failed to mark extension connected:", error);
    }
  }
  markExtensionConnected();
  window.addEventListener("message", (event) => {
    if (event.origin !== window.location.origin)
      return;
    if (event.data?.type === "TMO_CHECK_EXTENSION") {
      try {
        const version = getExtensionVersion();
        if (!version)
          return;
        window.postMessage({
          type: "TMO_EXTENSION_PRESENT",
          version
        }, "*");
        markExtensionConnected();
      } catch (error) {
        console.warn("[TrackMyOPT] Failed to respond to extension check:", error);
      }
    }
  });
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") {
      markExtensionConnected();
    }
  });
  console.log("[TrackMyOPT Extension] Content script loaded");
})();
